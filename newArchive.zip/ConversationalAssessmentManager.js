const NEETKnowledgeBase = require('../knowledge-base/NEETKnowledgeBase');
const LLMService = require('../services/LLMService');
const LambdaConnector = require('../services/LambdaConnector');
const AdaptiveDPPService = require('../services/AdaptiveDPPService');
const StudyTechniqueService = require('../services/StudyTechniqueService');
const SolutionGeneratorService = require('../services/SolutionGeneratorService');

/**
 * Conversational Assessment Manager
 * Handles intelligent conversation flow for student assessment and guidance
 */
class ConversationalAssessmentManager {
  constructor(lambdaConnector, llmService) {
    this.lambdaConnector = lambdaConnector || new LambdaConnector();
    this.llmService = llmService || new LLMService();
    this.knowledgeBase = new NEETKnowledgeBase();
    this.adaptiveDPPService = new AdaptiveDPPService(this.lambdaConnector);
    this.studyTechniqueService = new StudyTechniqueService(this.llmService);
    this.solutionGeneratorService = new SolutionGeneratorService(this.llmService);
    this.conversationStates = new Map();
    this.assessmentResults = new Map();
    this.sessionTimeout = 3600000; // 1 hour
  }

  /**
   * Initialize knowledge base
   * @returns {Promise<void>}
   */
  async initialize() {
    try {
      await this.knowledgeBase.loadSyllabusData();
      console.log('✅ AI Coach Assessment Manager initialized');
    } catch (error) {
      console.error('❌ Failed to initialize AI Coach:', error.message);
      throw error;
    }
  }

  /**
   * Start conversational assessment for a student
   * @param {string} studentId - Student ID
   * @param {Object} initialContext - Initial context (optional)
   * @returns {Promise<Object>} Assessment response
   */
  async startConversationalAssessment(studentId, initialContext = {}) {
    console.log(`🤖 Starting AI Coach conversation for student: ${studentId}`);
    
    try {
      // Get academic context
      const academicContext = this.knowledgeBase.getCurrentAcademicContext();
      
      // Check if student exists in database
      const studentExists = await this.checkStudentInDatabase(studentId, initialContext);
      
      if (studentExists.exists && studentExists.hasActivity) {
        // Student exists with activity - analyze their performance data
        return await this.analyzeExistingStudent(studentId, academicContext, initialContext);
      } else {
        // New student or no activity - start discovery conversation
        return await this.startDiscoveryConversation(studentId, academicContext, initialContext);
      }
    } catch (error) {
      console.error(`❌ Failed to start assessment for student ${studentId}:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Continue conversation with student response
   * @param {string} studentId - Student ID
   * @param {string} studentResponse - Student's response
   * @param {Object} additionalContext - Additional context
   * @returns {Promise<Object>} Next conversation step
   */
  async continueConversation(studentId, studentResponse, additionalContext = {}) {
    console.log(`💬 Continuing conversation for student: ${studentId}`);
    
    try {
      const conversationState = this.getConversationState(studentId);
      if (!conversationState) {
        return this.getErrorResponse('No active conversation found. Please start a new assessment.');
      }

      // Check for motivational triggers
      if (this.needsMotivationalSupport(studentResponse)) {
        return await this.handleMotivationalFlow(studentId, studentResponse, additionalContext);
      }

      // Update conversation state with response
      conversationState.addResponse(studentResponse);
      
      // Get academic context
      const academicContext = this.knowledgeBase.getCurrentAcademicContext();
      
      // Determine next step based on current phase
      switch (conversationState.currentPhase) {
        case 'discovery':
          return await this.handleDiscoveryPhase(studentId, conversationState, academicContext);
        
        case 'assessment':
          return await this.handleAssessmentPhase(studentId, conversationState, academicContext);
        
        case 'analysis':
          return await this.handleAnalysisPhase(studentId, conversationState, academicContext);
        
        case 'guidance':
          return await this.handleGuidancePhase(studentId, conversationState, academicContext);
        
        case 'motivation':
          return await this.handleMotivationPhase(studentId, conversationState, academicContext);
        
        default:
          return await this.handleUnknownPhase(studentId, conversationState, academicContext);
      }
    } catch (error) {
      console.error(`❌ Failed to continue conversation for ${studentId}:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Check if student exists in database
   * @param {string} studentId - Student ID
   * @param {Object} context - Context containing userId if available
   * @returns {Promise<Object>} Student existence info
   */
  async checkStudentInDatabase(studentId, context = {}) {
    try {
      // Use userId from context if available, otherwise try studentId
      const lookupId = context.userId || studentId;
      const studentData = await this.lambdaConnector.getStudentData(lookupId);
      
      if (studentData) {
        // Student exists and has performance data
        const hasActivity = (studentData.total_questions && studentData.total_questions > 0) ||
                           (studentData.test_breakdown && studentData.test_breakdown.total > 0);
        
        console.log(`📊 Student ${studentId} exists: true, has activity: ${hasActivity}`);
        return { 
          exists: true, 
          hasActivity: hasActivity,
          studentData: studentData 
        };
      } else {
        console.log(`📊 Student ${studentId} exists: false, has activity: false`);
        return { exists: false, hasActivity: false };
      }
    } catch (error) {
      console.log(`ℹ️ Could not check student ${studentId}, treating as new student`);
      return { exists: false, hasActivity: false };
    }
  }

  /**
   * Get enhanced student data with adaptive DPP performance
   * @param {string} userId - User ID (can be name, email, or numeric ID)
   * @returns {Promise<Object>} Enhanced student data with adaptive DPP insights
   */
  async getEnhancedStudentData(userId) {
    try {
      console.log(`🔍 Getting enhanced student data for userId: ${userId}`);
      
      // Get basic student data (try different lookup methods)
      let basicStudentData = null;
      
      // Try numeric lookup first
      if (!isNaN(userId)) {
        basicStudentData = await this.lambdaConnector.getStudentData(parseInt(userId));
      }
      
      // If not found and looks like email/name, try identity lookup
      if (!basicStudentData && (userId.includes('@') || userId.includes(' '))) {
        const [name, email] = userId.includes('@') ? [null, userId] : [userId, null];
        basicStudentData = await this.lambdaConnector.getStudentByIdentity(name, email);
      }
      
      // Get detailed adaptive DPP performance (only if we have numeric user ID)
      let adaptiveDPPData = null;
      let numericUserId = null;
      
      if (basicStudentData?.userId) {
        numericUserId = basicStudentData.userId;
        adaptiveDPPData = await this.adaptiveDPPService.getAdaptiveDPPPerformance(numericUserId);
      } else if (!isNaN(userId)) {
        numericUserId = parseInt(userId);
        adaptiveDPPData = await this.adaptiveDPPService.getAdaptiveDPPPerformance(numericUserId);
      }
      
      // If user has previous adaptive DPP data, compare with current state
      let progressComparison = null;
      if (adaptiveDPPData && adaptiveDPPData.totalChapters > 0) {
        progressComparison = await this.adaptiveDPPService.compareWithPreviousState(numericUserId, adaptiveDPPData);
      }
      
      const enhancedData = {
        basicData: basicStudentData,
        adaptiveDPP: adaptiveDPPData,
        progressComparison: progressComparison,
        dataQuality: this.assessDataQuality(basicStudentData, adaptiveDPPData),
        numericUserId: numericUserId,
        timestamp: new Date().toISOString()
      };
      
      console.log(`✅ Enhanced student data: Basic[${!!basicStudentData}] DPP[${!!adaptiveDPPData}] Chapters[${adaptiveDPPData?.totalChapters || 0}]`);
      return enhancedData;
      
    } catch (error) {
      console.error(`❌ Failed to get enhanced student data:`, error.message);
      return { basicData: null, adaptiveDPP: null, progressComparison: null, dataQuality: { hasBasicData: false, hasAdaptiveDPP: false } };
    }
  }

  /**
   * Assess quality of available student data
   * @param {Object} basicData - Basic student data from Lambda
   * @param {Object} adaptiveDPPData - Adaptive DPP performance data
   * @returns {Object} Data quality assessment
   */
  assessDataQuality(basicData, adaptiveDPPData) {
    const quality = {
      hasBasicData: !!basicData,
      hasAdaptiveDPP: !!(adaptiveDPPData && adaptiveDPPData.totalChapters > 0),
      dataCompleteness: 'minimal',
      recommendations: [],
      analysisApproach: 'discovery' // Default to discovery if no data
    };
    
    if (basicData && adaptiveDPPData && adaptiveDPPData.totalChapters > 0) {
      quality.dataCompleteness = 'comprehensive';
      quality.analysisApproach = 'adaptive_analysis';
      quality.recommendations.push('Use adaptive DPP insights for comprehensive study planning');
      quality.recommendations.push('Compare current vs previous performance for growth tracking');
      quality.recommendations.push('Use difficulty band analysis for targeted improvement');
    } else if (basicData) {
      quality.dataCompleteness = 'basic';
      quality.analysisApproach = 'basic_analysis';
      quality.recommendations.push('Use basic performance data for initial assessment');
      quality.recommendations.push('Recommend adaptive DPP for detailed progress tracking');
    } else if (adaptiveDPPData && adaptiveDPPData.totalChapters > 0) {
      quality.dataCompleteness = 'adaptive_only';
      quality.analysisApproach = 'adaptive_only';
      quality.recommendations.push('Use detailed DPP performance for targeted recommendations');
      quality.recommendations.push('Leverage difficulty band insights for study planning');
    }
    
    return quality;
  }

  /**
   * Analyze existing student with performance data
   * @param {string} studentId - Student ID
   * @param {Object} academicContext - Academic context
   * @param {Object} context - Context containing userId if available
   * @returns {Promise<Object>} Analysis response
   */
  async analyzeExistingStudent(studentId, academicContext, context = {}) {
    console.log(`📊 Analyzing existing student: ${studentId}`);
    
    try {
      // Get comprehensive student data - use userId from context if available
      const lookupId = context.userId || studentId;
      const studentData = await this.lambdaConnector.getStudentData(lookupId);
      
      if (!studentData) {
        return await this.startDiscoveryConversation(studentId, academicContext);
      }

      // Create conversation state for existing student
      const conversationState = this.createConversationState(studentId, 'analysis');
      conversationState.studentData = studentData;
      
      // Generate AI-powered analysis
      const analysisPrompt = this.buildExistingStudentAnalysisPrompt(studentData, academicContext);
      const aiAnalysis = await this.llmService.analyzeStudentPreparation(studentData, academicContext);
      
      // Store analysis results
      const analysisResult = {
        type: 'existing_student_analysis',
        studentId,
        timestamp: new Date().toISOString(),
        analysisData: aiAnalysis,
        studentData: studentData,
        academicContext,
        recommendations: this.generateRecommendations(aiAnalysis, academicContext)
      };
      
      this.assessmentResults.set(studentId, analysisResult);
      
      return {
        success: true,
        type: 'existing_student_analysis',
        message: this.formatExistingStudentResponse(aiAnalysis, academicContext),
        analysisResult,
        nextAction: 'provide_guidance',
        conversationState: conversationState.getPublicState()
      };
    } catch (error) {
      console.error(`❌ Failed to analyze existing student ${studentId}:`, error.message);
      return await this.startDiscoveryConversation(studentId, academicContext);
    }
  }

  /**
   * Start discovery conversation for new student
   * @param {string} studentId - Student ID
   * @param {Object} academicContext - Academic context
   * @param {Object} initialContext - Initial context
   * @returns {Promise<Object>} Discovery response
   */
  async startDiscoveryConversation(studentId, academicContext, initialContext = {}) {
    console.log(`🔍 Starting discovery conversation for student: ${studentId}`);
    
    try {
      // Create conversation state
      const conversationState = this.createConversationState(studentId, 'discovery');
      conversationState.academicContext = academicContext;
      
      // Generate initial conversation response
      const initialResponse = await this.generateInitialConversationResponse(academicContext, initialContext);
      
      return {
        success: true,
        type: 'discovery_start',
        message: initialResponse.message,
        question: initialResponse.question,
        phase: 'discovery',
        academicContext: {
          currentMonth: academicContext.currentMonthName,
          neetMonthsRemaining: academicContext.neetExamMonthsRemaining.months,
          teachingPhase: academicContext.currentTeachingPhase,
          examPressure: academicContext.examPressure.level
        },
        conversationState: conversationState.getPublicState()
      };
    } catch (error) {
      console.error(`❌ Failed to start discovery conversation:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Handle discovery phase of conversation
   * @param {string} studentId - Student ID
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Discovery phase response
   */
  async handleDiscoveryPhase(studentId, conversationState, academicContext) {
    console.log(`🔍 Handling discovery phase for student: ${studentId}`);
    
    try {
      const lastResponse = conversationState.getLastResponse();
      
      // Generate next conversation step using AI
      const conversationResponse = await this.llmService.generateConversationalResponse(
        conversationState.getContextForLLM(),
        lastResponse,
        academicContext
      );
      
      // Update conversation state
      conversationState.addAIResponse(conversationResponse);
      
      // Check if we have enough information to move to assessment
      if (conversationState.questionsAsked >= 5 || this.hasEnoughInfoForAssessment(conversationState)) {
        conversationState.moveToPhase('assessment');
        return await this.startAssessmentPhase(studentId, conversationState, academicContext);
      }
      
      return {
        success: true,
        type: 'discovery_continue',
        message: conversationResponse.response,
        question: conversationResponse.nextQuestion,
        phase: 'discovery',
        progress: {
          questionsAsked: conversationState.questionsAsked,
          totalQuestions: 5,
          completionPercentage: (conversationState.questionsAsked / 5) * 100
        },
        conversationState: conversationState.getPublicState()
      };
    } catch (error) {
      console.error(`❌ Failed to handle discovery phase:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Start assessment phase
   * @param {string} studentId - Student ID
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Assessment start response
   */
  async startAssessmentPhase(studentId, conversationState, academicContext) {
    console.log(`📝 Starting assessment phase for student: ${studentId}`);
    
    try {
      // Analyze discovery responses to determine assessment focus
      const assessmentFocus = this.determineAssessmentFocus(conversationState, academicContext);
      
      // Generate assessment questions
      const assessmentQuestions = await this.generateAssessmentQuestions(assessmentFocus, academicContext);
      
      conversationState.assessmentQuestions = assessmentQuestions;
      conversationState.currentQuestionIndex = 0;
      
      return {
        success: true,
        type: 'assessment_start',
        message: 'Great! Based on our conversation, I\'d like to do a quick assessment to better understand your preparation level.',
        question: assessmentQuestions[0],
        phase: 'assessment',
        progress: {
          currentQuestion: 1,
          totalQuestions: assessmentQuestions.length,
          completionPercentage: 0
        },
        conversationState: conversationState.getPublicState()
      };
    } catch (error) {
      console.error(`❌ Failed to start assessment phase:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Handle assessment phase
   * @param {string} studentId - Student ID
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Assessment phase response
   */
  async handleAssessmentPhase(studentId, conversationState, academicContext) {
    console.log(`📝 Handling assessment phase for student: ${studentId}`);
    
    try {
      const currentQuestionIndex = conversationState.currentQuestionIndex;
      const totalQuestions = conversationState.assessmentQuestions.length;
      
      // Move to next question
      conversationState.currentQuestionIndex++;
      
      if (conversationState.currentQuestionIndex >= totalQuestions) {
        // Assessment complete, move to analysis
        conversationState.moveToPhase('analysis');
        return await this.startAnalysisPhase(studentId, conversationState, academicContext);
      }
      
      const nextQuestion = conversationState.assessmentQuestions[conversationState.currentQuestionIndex];
      
      return {
        success: true,
        type: 'assessment_continue',
        message: 'Thank you for your response.',
        question: nextQuestion,
        phase: 'assessment',
        progress: {
          currentQuestion: conversationState.currentQuestionIndex + 1,
          totalQuestions: totalQuestions,
          completionPercentage: ((conversationState.currentQuestionIndex + 1) / totalQuestions) * 100
        },
        conversationState: conversationState.getPublicState()
      };
    } catch (error) {
      console.error(`❌ Failed to handle assessment phase:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Start analysis phase
   * @param {string} studentId - Student ID
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Analysis phase response
   */
  async startAnalysisPhase(studentId, conversationState, academicContext) {
    console.log(`📊 Starting analysis phase for student: ${studentId}`);
    
    try {
      // Compile all conversation data
      const conversationData = conversationState.getComprehensiveData();
      
      // Generate AI analysis
      const aiAnalysis = await this.llmService.analyzeStudentPreparation(conversationData, academicContext);
      
      // Store analysis results
      const analysisResult = {
        type: 'conversation_analysis',
        studentId,
        timestamp: new Date().toISOString(),
        conversationData,
        analysisData: aiAnalysis,
        academicContext,
        recommendations: this.generateRecommendations(aiAnalysis, academicContext)
      };
      
      this.assessmentResults.set(studentId, analysisResult);
      
      // Move to guidance phase
      conversationState.moveToPhase('guidance');
      conversationState.analysisResult = analysisResult;
      
      return {
        success: true,
        type: 'analysis_complete',
        message: this.formatAnalysisResponse(aiAnalysis, academicContext),
        analysisResult,
        phase: 'guidance',
        nextAction: 'provide_guidance',
        conversationState: conversationState.getPublicState()
      };
    } catch (error) {
      console.error(`❌ Failed to start analysis phase:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Handle guidance phase
   * @param {string} studentId - Student ID
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Guidance phase response
   */
  async handleGuidancePhase(studentId, conversationState, academicContext) {
    console.log(`🎯 Handling guidance phase for student: ${studentId}`);
    
    try {
      const analysisResult = conversationState.analysisResult;
      
      // Generate personalized guidance
      const guidance = await this.llmService.generatePersonalizedGuidance(
        analysisResult.analysisData,
        academicContext
      );
      
      return {
        success: true,
        type: 'guidance_provided',
        message: this.formatGuidanceResponse(guidance, academicContext),
        guidance,
        phase: 'complete',
        nextAction: 'conversation_complete',
        conversationState: conversationState.getPublicState()
      };
    } catch (error) {
      console.error(`❌ Failed to handle guidance phase:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Handle unknown phase
   * @param {string} studentId - Student ID
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Recovery response
   */
  async handleUnknownPhase(studentId, conversationState, academicContext) {
    console.log(`❓ Handling unknown phase for student: ${studentId}`);
    
    // Reset to discovery phase
    conversationState.moveToPhase('discovery');
    
    return {
      success: true,
      type: 'phase_reset',
      message: 'Let me help you with your NEET preparation assessment.',
      question: 'Which class are you currently in - 11th or 12th?',
      phase: 'discovery',
      conversationState: conversationState.getPublicState()
    };
  }

  /**
   * Check if student needs motivational support using semantic pattern recognition
   * @param {string} studentResponse - Student's response
   * @returns {boolean} Whether motivational support is needed
   */
  needsMotivationalSupport(studentResponse) {
    const response = studentResponse.toLowerCase();
    
    // Pattern categories with semantic variations
    const patterns = {
      beginnerPatterns: [
        'beginner', 'complete beginner', 'total beginner', 'absolute beginner',
        'new to', 'new at', 'fresh to', 'starting from zero', 'zero knowledge',
        'never studied', 'haven\'t studied', 'not studied', 'no experience',
        'first time', 'just starting', 'starting out', 'complete novice'
      ],
      
      overwhelmedPatterns: [
        'overwhelmed', 'too much', 'so much', 'massive', 'huge syllabus',
        'confused', 'lost', 'clueless', 'no idea', 'don\'t understand',
        'complicated', 'complex', 'difficult to understand'
      ],
      
      startingQuestions: [
        'how should i start', 'where should i start', 'how to start',
        'where to begin', 'how to begin', 'where do i start',
        'what should i do first', 'how do i begin', 'starting point',
        'first step', 'initial step', 'beginning approach'
      ],
      
      emotionalStates: [
        'scared', 'afraid', 'nervous', 'worried', 'anxious', 'stressed',
        'panicked', 'concerned', 'frightened', 'apprehensive', 'uncertain',
        'unsure', 'doubtful', 'hesitant', 'insecure'
      ],
      
      timeRelatedConcerns: [
        'late starter', 'starting late', 'behind schedule', 'running out of time',
        'not enough time', 'limited time', 'short time', 'time crunch',
        'delayed start', 'last minute'
      ],
      
      preparationStatus: [
        'zero preparation', 'no preparation', 'unprepared', 'not prepared',
        'haven\'t started', 'not started', 'didn\'t start', 'yet to start',
        'planning to start', 'about to start', 'thinking of starting'
      ]
    };
    
    // Check for combinations of patterns (more sophisticated matching)
    const patternMatches = {};
    for (const [category, categoryPatterns] of Object.entries(patterns)) {
      patternMatches[category] = categoryPatterns.some(pattern => 
        response.includes(pattern) || this.checkSemanticSimilarity(response, pattern)
      );
    }
    
    // Sophisticated decision logic
    const matchCount = Object.values(patternMatches).filter(Boolean).length;
    
    // High confidence triggers
    if (patternMatches.beginnerPatterns && patternMatches.startingQuestions) return true;
    if (patternMatches.overwhelmedPatterns && (patternMatches.startingQuestions || patternMatches.emotionalStates)) return true;
    if (patternMatches.preparationStatus && patternMatches.startingQuestions) return true;
    if (patternMatches.timeRelatedConcerns && patternMatches.emotionalStates) return true;
    
    // Medium confidence (2+ pattern categories)
    if (matchCount >= 2) return true;
    
    // Single strong indicators
    if (patternMatches.startingQuestions && this.containsClassReference(response)) return true;
    if (patternMatches.beginnerPatterns && this.containsStudyReference(response)) return true;
    
    return false;
  }

  /**
   * Check semantic similarity for pattern variations
   * @param {string} response - Student response
   * @param {string} pattern - Pattern to match
   * @returns {boolean} Whether semantically similar
   */
  checkSemanticSimilarity(response, pattern) {
    // Simple semantic variations check
    const synonymMap = {
      'start': ['begin', 'commence', 'initiate', 'launch'],
      'beginner': ['novice', 'newbie', 'starter', 'learner'],
      'confused': ['puzzled', 'perplexed', 'baffled', 'mystified'],
      'scared': ['afraid', 'fearful', 'terrified', 'intimidated'],
      'study': ['learn', 'prepare', 'practice', 'review'],
      'difficult': ['hard', 'tough', 'challenging', 'complex']
    };
    
    for (const [word, synonyms] of Object.entries(synonymMap)) {
      if (pattern.includes(word)) {
        return synonyms.some(synonym => response.includes(synonym));
      }
    }
    
    return false;
  }

  /**
   * Check if response contains class level reference
   * @param {string} response - Student response
   * @returns {boolean} Whether contains class reference
   */
  containsClassReference(response) {
    const classPatterns = [
      'class 11', 'class 12', '11th', '12th', 'grade 11', 'grade 12',
      'std 11', 'std 12', 'standard 11', 'standard 12'
    ];
    return classPatterns.some(pattern => response.includes(pattern));
  }

  /**
   * Check if response contains study-related terms
   * @param {string} response - Student response
   * @returns {boolean} Whether contains study reference
   */
  containsStudyReference(response) {
    const studyPatterns = [
      'study', 'preparation', 'neet', 'exam', 'learn', 'practice',
      'syllabus', 'topics', 'subjects', 'physics', 'chemistry', 'biology'
    ];
    return studyPatterns.some(pattern => response.includes(pattern));
  }

  /**
   * Handle motivational flow for overwhelmed/beginner students
   * @param {string} studentId - Student ID
   * @param {string} studentResponse - Student's response
   * @param {Object} additionalContext - Additional context
   * @returns {Promise<Object>} Motivational response
   */
  async handleMotivationalFlow(studentId, studentResponse, additionalContext = {}) {
    console.log(`🌟 Starting motivational flow for student: ${studentId}`);
    
    try {
      // Get or create conversation state in motivation phase
      let conversationState = this.getConversationState(studentId);
      if (!conversationState) {
        conversationState = this.createConversationState(studentId, 'motivation');
      } else {
        conversationState.moveToPhase('motivation');
      }
      
      // Store the triggering response
      conversationState.addResponse(studentResponse);
      
      // Detect dropper status and NEET score
      const dropperInfo = this.detectDropperAndScore(studentResponse);
      
      conversationState.motivationalContext = {
        triggerResponse: studentResponse,
        isBeginnerStudent: this.isBeginnerStudent(studentResponse),
        classLevel: this.extractClassFromResponse(studentResponse),
        emotionalState: this.detectEmotionalState(studentResponse),
        isDropper: dropperInfo.isDropper,
        neetScore: dropperInfo.neetScore,
        hasNeetScore: dropperInfo.hasScore
      };
      
      // If dropper but no score mentioned, ask for it
      if (dropperInfo.isDropper && !dropperInfo.hasScore && !conversationState.neetScoreAsked) {
        conversationState.neetScoreAsked = true;
        return {
          success: true,
          type: 'neet_score_inquiry',
          message: `I see you're a dropper! That shows real determination - many NEET toppers are droppers who used their second chance wisely. 💪\n\n🎯 **Did you know?** 40% of top NEET scorers are droppers who improved their scores significantly in their second attempt!\n\nTo give you the most targeted guidance based on research from 22.7 lakh NEET candidates, could you share your previous NEET score? This will help me identify your specific weak areas and create a personalized improvement strategy.`,
          question: "What was your NEET score last year? (This helps me create a research-backed improvement plan)",
          phase: 'motivation',
          nextAction: 'neet_score_analysis',
          conversationState: conversationState.getPublicState()
        };
      }
      
      // If we have NEET score, get weak spots analysis
      if (conversationState.motivationalContext.hasNeetScore) {
        try {
          const weakSpotsAnalysis = await this.knowledgeBase.getWeakSpotsByScore(conversationState.motivationalContext.neetScore);
          conversationState.neetWeakSpotsAnalysis = weakSpotsAnalysis;
          console.log(`📊 NEET weak spots analysis loaded for score: ${conversationState.motivationalContext.neetScore} (${weakSpotsAnalysis.category})`);
        } catch (error) {
          console.warn('⚠️ Failed to load NEET weak spots analysis:', error.message);
        }
      }
      
      // Get academic context
      const academicContext = this.knowledgeBase.getCurrentAcademicContext();
      
      // Generate motivational response
      const motivationalResponse = await this.generateMotivationalResponse(
        conversationState.motivationalContext, 
        academicContext
      );
      
      return {
        success: true,
        type: 'motivational_support',
        message: motivationalResponse.message,
        question: motivationalResponse.question,
        motivationalFacts: motivationalResponse.facts,
        neetAnalysis: conversationState.neetWeakSpotsAnalysis ? {
          category: conversationState.neetWeakSpotsAnalysis.category,
          scoreRange: conversationState.neetWeakSpotsAnalysis.scoreRange,
          interventionPriority: conversationState.neetWeakSpotsAnalysis.interventionPriority,
          overallWeakSpots: conversationState.neetWeakSpotsAnalysis.overallWeakSpots?.slice(0, 3) // Top 3 weak spots
        } : null,
        phase: 'motivation',
        nextAction: 'time_assessment',
        conversationState: conversationState.getPublicState()
      };
    } catch (error) {
      console.error(`❌ Failed to handle motivational flow:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Handle motivation phase continuation
   * @param {string} studentId - Student ID
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Motivation phase response
   */
  async handleMotivationPhase(studentId, conversationState, academicContext) {
    console.log(`🌟 Handling motivation phase for student: ${studentId}`);
    
    try {
      const motivationalContext = conversationState.motivationalContext;
      const lastResponse = conversationState.getLastResponse();
      
      // Progress through motivation sub-phases
      if (!conversationState.timeAssessed) {
        return await this.handleTimeAssessment(studentId, conversationState, academicContext);
      } else if (!conversationState.syllabusAnalyzed) {
        return await this.handleSyllabusAnalysis(studentId, conversationState, academicContext);
      } else {
        return await this.generatePersonalizedStudyPlan(studentId, conversationState, academicContext);
      }
    } catch (error) {
      console.error(`❌ Failed to handle motivation phase:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Check if student is a beginner
   * @param {string} response - Student response
   * @returns {boolean} Whether student is beginner
   */
  isBeginnerStudent(response) {
    const beginnerKeywords = ['beginner', 'new', 'start', 'zero', 'never', 'haven\'t'];
    return beginnerKeywords.some(keyword => response.toLowerCase().includes(keyword));
  }

  /**
   * Extract class level from response
   * @param {string} response - Student response
   * @returns {string} Class level
   */
  extractClassFromResponse(response) {
    if (response.includes('11')) return '11';
    if (response.includes('12')) return '12';
    return 'unknown';
  }

  /**
   * Detect emotional state from response
   * @param {string} response - Student response
   * @returns {string} Emotional state
   */
  detectEmotionalState(response) {
    const emotions = {
      'overwhelmed': ['overwhelmed', 'too much', 'confused', 'lost'],
      'anxious': ['worried', 'scared', 'nervous', 'stressed', 'anxious'],
      'uncertain': ['don\'t know', 'unsure', 'confused', 'help'],
      'motivated': ['ready', 'determined', 'want to', 'willing'],
      'dropper': ['dropper', 'drop year', 'appeared', 'gave neet', 'attempted neet', 'previous neet']
    };
    
    const response_lower = response.toLowerCase();
    for (const [emotion, keywords] of Object.entries(emotions)) {
      if (keywords.some(keyword => response_lower.includes(keyword))) {
        return emotion;
      }
    }
    return 'neutral';
  }

  /**
   * Detect if student is a dropper and extract NEET score
   * @param {string} response - Student response
   * @returns {Object} Dropper detection and score extraction
   */
  detectDropperAndScore(response) {
    const response_lower = response.toLowerCase();
    
    // Dropper detection keywords
    const dropperKeywords = [
      'dropper', 'drop year', 'appeared', 'gave neet', 'attempted neet', 
      'previous neet', 'last year', 'already given', 'took neet'
    ];
    
    const isDropper = dropperKeywords.some(keyword => response_lower.includes(keyword));
    
    // Score extraction patterns
    const scorePatterns = [
      /scored?\s*(\d{1,3})/i,
      /got\s*(\d{1,3})/i,
      /marks?\s*(\d{1,3})/i,
      /score\s*was\s*(\d{1,3})/i,
      /(\d{1,3})\s*marks?/i,
      /(\d{1,3})\s*score/i,
      /(\d{1,3})\s*out\s*of\s*720/i
    ];
    
    let extractedScore = null;
    for (const pattern of scorePatterns) {
      const match = response.match(pattern);
      if (match) {
        const score = parseInt(match[1]);
        if (score >= 0 && score <= 720) {
          extractedScore = score;
          break;
        }
      }
    }
    
    return {
      isDropper: isDropper,
      neetScore: extractedScore,
      hasScore: extractedScore !== null
    };
  }

  /**
   * Generate motivational response for beginners
   * @param {Object} motivationalContext - Motivational context
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Motivational response
   */
  async generateMotivationalResponse(motivationalContext, academicContext) {
    const { classLevel, isBeginnerStudent, emotionalState } = motivationalContext;
    const { neetExamMonthsRemaining } = academicContext;
    
    // Get motivational facts based on context
    const motivationalFacts = this.getMotivationalFacts(classLevel, neetExamMonthsRemaining.months);
    
    const response = {
      message: this.buildMotivationalMessage(motivationalContext, academicContext, motivationalFacts),
      question: "Before we create your personalized study plan, I'd like to understand your daily schedule. How many hours can you realistically dedicate to NEET preparation each day?",
      facts: motivationalFacts
    };
    
    return response;
  }

  /**
   * Get motivational facts for students
   * @param {string} classLevel - Class level (11/12)
   * @param {number} monthsRemaining - Months until NEET
   * @returns {Array} Motivational facts
   */
  getMotivationalFacts(classLevel, monthsRemaining) {
    const facts = [];
    
    // Success stories based on class level
    if (classLevel === '12') {
      facts.push("📊 **65% of NEET toppers** started their serious preparation only in Class 12!");
      facts.push("🎯 **Even with 6 months** of focused study, students have secured AIR under 1000");
      facts.push("💪 **Late starters often perform better** because they have clarity and urgency");
    } else {
      facts.push("🌟 **Starting in Class 11 gives you a huge advantage** - you have time to build strong foundations");
      facts.push("📈 **Students who start early** have 3x higher chances of securing medical seats");
      facts.push("🎓 **Class 11 concepts form 40% of NEET questions** - you're building your future score now!");
    }
    
    // Time-based motivation
    if (monthsRemaining > 12) {
      facts.push(`⏰ **You have ${monthsRemaining} months** - that's more than enough time for comprehensive preparation!`);
      facts.push("🚀 **With consistent daily study**, you can cover the entire syllabus 2-3 times");
    } else if (monthsRemaining > 6) {
      facts.push(`⚡ **${monthsRemaining} months is perfect** for intensive preparation - many toppers used similar timeframes!`);
      facts.push("🎯 **Focus on high-weightage topics** and you can still achieve excellent scores");
    } else {
      facts.push(`🔥 **${monthsRemaining} months of focused study** can still lead to great results!`);
      facts.push("💎 **Quality over quantity** - strategic preparation beats lengthy unfocused study");
    }
    
    // Universal motivation
    facts.push("🧠 **NEET is about understanding, not memorization** - anyone can master it with the right approach");
    facts.push("📚 **Every expert was once a beginner** - your journey to success starts with this first step!");
    
    return facts;
  }

  /**
   * Build motivational message
   * @param {Object} motivationalContext - Motivational context
   * @param {Object} academicContext - Academic context
   * @param {Array} facts - Motivational facts
   * @returns {string} Motivational message
   */
  buildMotivationalMessage(motivationalContext, academicContext, facts) {
    const { classLevel, emotionalState, isBeginnerStudent } = motivationalContext;
    const { neetExamMonthsRemaining } = academicContext;
    
    let message = "";
    
    // Empathetic opening based on emotional state
    if (emotionalState === 'overwhelmed') {
      message += "I completely understand feeling overwhelmed - NEET preparation can seem daunting at first. But here's the thing: **you're not alone, and it's absolutely manageable!** 🌟\n\n";
    } else if (emotionalState === 'anxious') {
      message += "It's completely normal to feel anxious about NEET preparation. That anxiety shows you care about your future, which is actually a strength! Let me help turn that anxiety into focused action. 💪\n\n";
    } else if (isBeginnerStudent) {
      message += "Being a complete beginner is actually a **huge advantage**! You don't have any bad study habits to unlearn, and you can build the right foundation from day one. 🚀\n\n";
    } else {
      message += "Great question! Starting your NEET journey is an exciting step, and I'm here to make it as clear and achievable as possible. ✨\n\n";
    }
    
    // Add motivational facts
    message += "**Here are some encouraging facts to boost your confidence:**\n\n";
    facts.forEach(fact => {
      message += fact + "\n\n";
    });
    
    // Action-oriented conclusion
    message += `**The key is starting with a clear, personalized plan.** With ${neetExamMonthsRemaining.months} months ahead of us, we can create a study strategy that's both achievable and effective for your specific situation.\n\n`;
    message += "Remember: **Every NEET topper started exactly where you are right now.** The difference? They took that first step and stayed consistent. Today, you're taking YOUR first step! 🎯";
    
    return message;
  }

  /**
   * Handle time availability assessment
   * @param {string} studentId - Student ID
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Time assessment response
   */
  async handleTimeAssessment(studentId, conversationState, academicContext) {
    console.log(`⏰ Handling time assessment for student: ${studentId}`);
    
    try {
      const lastResponse = conversationState.getLastResponse();
      const hoursPerDay = this.extractStudyHours(lastResponse);
      
      if (hoursPerDay > 0) {
        // Store time assessment
        conversationState.timeAssessed = true;
        conversationState.dailyStudyHours = hoursPerDay;
        
        // Calculate study capacity
        const studyCapacity = this.calculateStudyCapacity(hoursPerDay, academicContext);
        conversationState.studyCapacity = studyCapacity;
        
        return {
          success: true,
          type: 'time_assessment_complete',
          message: this.buildTimeAssessmentResponse(hoursPerDay, studyCapacity, academicContext),
          question: "Now let's check if you have any existing preparation. Have you studied any NEET topics before, or are you starting completely fresh?",
          studyCapacity: studyCapacity,
          phase: 'motivation',
          nextAction: 'syllabus_analysis',
          conversationState: conversationState.getPublicState()
        };
      } else {
        return {
          success: true,
          type: 'time_assessment_clarification',
          message: "I'd like to better understand your available study time. Could you please specify how many hours per day you can dedicate to NEET preparation? For example: '4 hours', '6 hours', etc.",
          question: "How many hours per day can you realistically study for NEET?",
          phase: 'motivation',
          conversationState: conversationState.getPublicState()
        };
      }
    } catch (error) {
      console.error(`❌ Failed to handle time assessment:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Handle syllabus coverage analysis
   * @param {string} studentId - Student ID
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Syllabus analysis response
   */
  async handleSyllabusAnalysis(studentId, conversationState, academicContext) {
    console.log(`📚 Handling syllabus analysis for student: ${studentId}`);
    
    try {
      const lastResponse = conversationState.getLastResponse();
      const preparationLevel = this.assessPreparationLevel(lastResponse);
      
      // Try to get student data from database
      let studentData = null;
      try {
        studentData = await this.lambdaConnector.getStudentData(studentId);
      } catch (error) {
        console.log(`ℹ️ No database access for student ${studentId}, proceeding with knowledge base analysis`);
      }
      
      // Calculate syllabus coverage
      const syllabusAnalysis = await this.calculateSyllabusCoverage(
        preparationLevel,
        studentData,
        conversationState,
        academicContext
      );
      
      conversationState.syllabusAnalyzed = true;
      conversationState.syllabusAnalysis = syllabusAnalysis;
      
      return {
        success: true,
        type: 'syllabus_analysis_complete',
        message: this.buildSyllabusAnalysisResponse(syllabusAnalysis, academicContext),
        syllabusAnalysis: syllabusAnalysis,
        phase: 'motivation',
        nextAction: 'generate_study_plan',
        conversationState: conversationState.getPublicState()
      };
    } catch (error) {
      console.error(`❌ Failed to handle syllabus analysis:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Generate personalized study plan
   * @param {string} studentId - Student ID
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Study plan response
   */
  async generatePersonalizedStudyPlan(studentId, conversationState, academicContext) {
    console.log(`📋 Generating personalized study plan for student: ${studentId}`);
    
    try {
      const { motivationalContext, dailyStudyHours, studyCapacity, syllabusAnalysis } = conversationState;
      
      // 🎯 NEW: Check if adaptive quiz should be recommended
      const adaptiveQuizRecommendation = await this.checkAdaptiveQuizRecommendation(studentId, syllabusAnalysis);
      
      // Generate comprehensive study plan
      const studyPlan = await this.createComprehensiveStudyPlan(
        motivationalContext,
        dailyStudyHours,
        studyCapacity,
        syllabusAnalysis,
        academicContext,
        adaptiveQuizRecommendation // Pass adaptive quiz recommendation
      );
      
      // 🔄 Save current state for future optimal level comparison
      if (adaptiveQuizRecommendation.shouldRecommend) {
        await this.saveAdaptiveQuizState(studentId, syllabusAnalysis, adaptiveQuizRecommendation);
      }
      
      conversationState.studyPlan = studyPlan;
      conversationState.adaptiveQuizRecommendation = adaptiveQuizRecommendation;
      conversationState.moveToPhase('complete');
      
      return {
        success: true,
        type: 'study_plan_generated',
        message: this.buildStudyPlanResponse(studyPlan, academicContext, adaptiveQuizRecommendation),
        studyPlan: studyPlan,
        adaptiveQuizRecommendation: adaptiveQuizRecommendation,
        phase: 'complete',
        nextAction: 'plan_implementation',
        conversationState: conversationState.getPublicState()
      };
    } catch (error) {
      console.error(`❌ Failed to generate study plan:`, error.message);
      return this.getErrorResponse(error.message);
    }
  }

  /**
   * Extract study hours from response
   * @param {string} response - Student response
   * @returns {number} Study hours per day
   */
  extractStudyHours(response) {
    const hourMatches = response.match(/(\d+)\s*(?:hours?|hrs?|h)/i);
    if (hourMatches) {
      return parseInt(hourMatches[1]);
    }
    
    // Try to find standalone numbers
    const numberMatches = response.match(/\b(\d+)\b/);
    if (numberMatches) {
      const number = parseInt(numberMatches[1]);
      if (number <= 16) { // Reasonable daily study hours
        return number;
      }
    }
    
    return 0;
  }

  /**
   * Calculate study capacity based on available hours with syllabus completion estimates
   * @param {number} hoursPerDay - Hours per day
   * @param {Object} academicContext - Academic context
   * @returns {Object} Study capacity analysis
   */
  calculateStudyCapacity(hoursPerDay, academicContext) {
    const { neetExamMonthsRemaining } = academicContext;
    const monthsRemaining = neetExamMonthsRemaining.months;
    const totalHours = hoursPerDay * 30 * monthsRemaining; // Approximate total hours
    
    // Calculate syllabus completion potential
    const syllabusEstimate = this.calculateSyllabusCompletionCapacity(hoursPerDay, monthsRemaining);
    
    return {
      dailyHours: hoursPerDay,
      monthsRemaining: monthsRemaining,
      totalHours: totalHours,
      capacity: this.assessCapacityLevel(hoursPerDay, monthsRemaining),
      subjectDistribution: this.calculateSubjectDistribution(hoursPerDay),
      recommendation: this.getCapacityRecommendation(hoursPerDay, monthsRemaining),
      syllabusCompletionEstimate: syllabusEstimate,
      topicsPerDay: syllabusEstimate.estimatedTopicsPerDay,
      completionProjection: syllabusEstimate.completionProjection
    };
  }

  /**
   * Calculate how much syllabus can be completed with given time
   * @param {number} hoursPerDay - Hours per day
   * @param {number} monthsRemaining - Months remaining
   * @returns {Object} Syllabus completion capacity
   */
  calculateSyllabusCompletionCapacity(hoursPerDay, monthsRemaining) {
    // NEET Syllabus Constants (based on NEET knowledge base)
    const TOTAL_NEET_TOPICS = 150; // Approximate total topics
    const SUBJECT_BREAKDOWN = {
      physics: 50,
      chemistry: 50, 
      biology: 50
    };
    
    // Time allocation per topic based on difficulty and hours available
    const timePerTopicHours = this.calculateTimePerTopic(hoursPerDay);
    
    // Calculate daily topic completion capacity
    const hoursForNewTopics = hoursPerDay * 0.6; // 60% for new topics, 40% for practice/revision
    const topicsPerDay = hoursForNewTopics / timePerTopicHours.average;
    
    // Total topics that can be covered
    const totalDaysAvailable = monthsRemaining * 30;
    const maxTopicsCanCover = Math.floor(topicsPerDay * totalDaysAvailable);
    
    // Completion percentage projection
    const completionPercentage = Math.min((maxTopicsCanCover / TOTAL_NEET_TOPICS) * 100, 100);
    
    return {
      estimatedTopicsPerDay: Math.round(topicsPerDay * 10) / 10, // Round to 1 decimal
      maxTopicsCanCover: Math.min(maxTopicsCanCover, TOTAL_NEET_TOPICS),
      completionProjection: {
        percentage: Math.round(completionPercentage),
        physics: Math.min(Math.floor(maxTopicsCanCover * 0.35), SUBJECT_BREAKDOWN.physics),
        chemistry: Math.min(Math.floor(maxTopicsCanCover * 0.35), SUBJECT_BREAKDOWN.chemistry),
        biology: Math.min(Math.floor(maxTopicsCanCover * 0.30), SUBJECT_BREAKDOWN.biology)
      },
      timeAllocation: {
        newTopics: Math.round(hoursPerDay * 0.6 * 10) / 10,
        practice: Math.round(hoursPerDay * 0.25 * 10) / 10,
        revision: Math.round(hoursPerDay * 0.15 * 10) / 10
      },
      qualityLevel: this.assessStudyQuality(hoursPerDay, topicsPerDay)
    };
  }

  /**
   * Calculate time needed per topic based on available hours
   * @param {number} hoursPerDay - Hours per day
   * @returns {Object} Time per topic breakdown
   */
  calculateTimePerTopic(hoursPerDay) {
    // Time allocation varies by study intensity
    if (hoursPerDay >= 8) {
      // Comprehensive study - more time per topic for deep understanding
      return {
        physics: 3.5, // Complex numerical problems need more time
        chemistry: 3.0, // Theory + reactions + numericals  
        biology: 2.5, // More reading but less problem-solving
        average: 3.0
      };
    } else if (hoursPerDay >= 6) {
      // Balanced study
      return {
        physics: 2.5,
        chemistry: 2.5,
        biology: 2.0,
        average: 2.3
      };
    } else if (hoursPerDay >= 4) {
      // Focused study - strategic approach
      return {
        physics: 2.0,
        chemistry: 2.0,
        biology: 1.5,
        average: 1.8
      };
    } else {
      // Minimal time - only high-yield topics
      return {
        physics: 1.5,
        chemistry: 1.5,
        biology: 1.0,
        average: 1.3
      };
    }
  }

  /**
   * Assess study quality based on time allocation
   * @param {number} hoursPerDay - Hours per day
   * @param {number} topicsPerDay - Topics per day
   * @returns {string} Quality assessment
   */
  assessStudyQuality(hoursPerDay, topicsPerDay) {
    if (hoursPerDay >= 8 && topicsPerDay <= 2) {
      return 'comprehensive'; // Deep understanding, multiple revisions
    } else if (hoursPerDay >= 6 && topicsPerDay <= 3) {
      return 'thorough'; // Good understanding, regular practice
    } else if (hoursPerDay >= 4 && topicsPerDay <= 4) {
      return 'focused'; // Concept clarity, targeted practice
    } else {
      return 'strategic'; // High-yield topics only, minimal depth
    }
  }

  /**
   * Assess capacity level
   * @param {number} hoursPerDay - Hours per day
   * @param {number} monthsRemaining - Months remaining
   * @returns {string} Capacity level
   */
  assessCapacityLevel(hoursPerDay, monthsRemaining) {
    const totalHours = hoursPerDay * 30 * monthsRemaining;
    
    if (totalHours >= 1500) return 'excellent';
    if (totalHours >= 1000) return 'good';
    if (totalHours >= 600) return 'moderate';
    return 'challenging';
  }

  /**
   * Calculate subject distribution
   * @param {number} hoursPerDay - Hours per day
   * @returns {Object} Subject distribution
   */
  calculateSubjectDistribution(hoursPerDay) {
    if (hoursPerDay >= 8) {
      return { physics: 3, chemistry: 3, biology: 2 };
    } else if (hoursPerDay >= 6) {
      return { physics: 2.5, chemistry: 2.5, biology: 1 };
    } else if (hoursPerDay >= 4) {
      return { physics: 1.5, chemistry: 1.5, biology: 1 };
    } else {
      return { physics: 1, chemistry: 1, biology: 1 };
    }
  }

  /**
   * Get capacity recommendation
   * @param {number} hoursPerDay - Hours per day
   * @param {number} monthsRemaining - Months remaining
   * @returns {string} Recommendation
   */
  getCapacityRecommendation(hoursPerDay, monthsRemaining) {
    if (hoursPerDay >= 8) {
      return "Excellent! This gives you ample time for comprehensive preparation and multiple revisions.";
    } else if (hoursPerDay >= 6) {
      return "Great! This is sufficient time for thorough preparation with proper planning.";
    } else if (hoursPerDay >= 4) {
      return "Good start! Focus on high-yield topics and efficient study methods.";
    } else {
      return "We'll need to be very strategic and focus on high-weightage topics for maximum impact.";
    }
  }

  /**
   * Assess preparation level from response
   * @param {string} response - Student response
   * @returns {string} Preparation level
   */
  assessPreparationLevel(response) {
    const response_lower = response.toLowerCase();
    
    if (response_lower.includes('fresh') || response_lower.includes('starting') || 
        response_lower.includes('never') || response_lower.includes('zero')) {
      return 'fresh';
    } else if (response_lower.includes('some') || response_lower.includes('little') ||
               response_lower.includes('basic')) {
      return 'basic';
    } else if (response_lower.includes('good') || response_lower.includes('decent') ||
               response_lower.includes('moderate')) {
      return 'moderate';
    } else {
      return 'fresh'; // Default to fresh for beginners
    }
  }

  /**
   * Calculate syllabus coverage with database integration and time-based projections
   * @param {string} preparationLevel - Preparation level
   * @param {Object} studentData - Student data from database
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Syllabus coverage analysis
   */
  async calculateSyllabusCoverage(preparationLevel, studentData, conversationState, academicContext) {
    try {
      // Get total NEET syllabus from knowledge base
      const totalSyllabus = this.knowledgeBase.getTotalSyllabusTopics();
      
      let coverage = {
        totalTopics: totalSyllabus.total,
        coveredTopics: 0,
        coveragePercentage: 0,
        subjectWiseCoverage: {
          physics: { total: totalSyllabus.physics, covered: 0, percentage: 0 },
          chemistry: { total: totalSyllabus.chemistry, covered: 0, percentage: 0 },
          biology: { total: totalSyllabus.biology, covered: 0, percentage: 0 }
        },
        strongTopics: [],
        weakTopics: [],
        unexploredTopics: [],
        priorityTopics: []
      };
      
      if (studentData && studentData.practiced_chapter_names) {
        // Use database data for coverage calculation
        coverage = await this.calculateDatabaseCoverage(studentData, totalSyllabus);
      } else {
        // Use knowledge base estimation based on preparation level
        coverage = this.estimateCoverageFromLevel(preparationLevel, totalSyllabus);
      }
      
      // Add time-based completion estimates
      if (conversationState.studyCapacity) {
        coverage.timeBasedProjection = this.calculateTimeBasedSyllabusProjection(
          coverage, 
          conversationState.studyCapacity,
          academicContext
        );
      }
      
      // Add priority recommendations
      coverage.priorityTopics = this.knowledgeBase.getHighWeightageTopics('all').slice(0, 15);
      
      return coverage;
    } catch (error) {
      console.error('❌ Failed to calculate syllabus coverage:', error.message);
      return this.getDefaultCoverage();
    }
  }

  /**
   * Calculate time-based syllabus completion projection
   * @param {Object} currentCoverage - Current coverage analysis
   * @param {Object} studyCapacity - Study capacity from time assessment
   * @param {Object} academicContext - Academic context
   * @returns {Object} Time-based projection
   */
  calculateTimeBasedSyllabusProjection(currentCoverage, studyCapacity, academicContext) {
    const { unexploredTopics } = currentCoverage;
    const { syllabusCompletionEstimate, monthsRemaining } = studyCapacity;
    
    // Calculate realistic completion based on time available
    const topicsWeCanStillCover = Math.min(
      unexploredTopics, 
      syllabusCompletionEstimate.maxTopicsCanCover
    );
    
    const finalCoverageProjection = {
      currentCoverage: currentCoverage.coveragePercentage,
      additionalCoverageInTimeframe: Math.round((topicsWeCanStillCover / currentCoverage.totalTopics) * 100),
      finalProjectedCoverage: Math.min(
        currentCoverage.coveragePercentage + Math.round((topicsWeCanStillCover / currentCoverage.totalTopics) * 100), 
        100
      ),
      topicsWeCanComplete: topicsWeCanStillCover,
      completionTimeline: this.calculateCompletionTimeline(topicsWeCanStillCover, syllabusCompletionEstimate, monthsRemaining),
      feasibilityAssessment: this.assessFeasibility(unexploredTopics, syllabusCompletionEstimate.maxTopicsCanCover)
    };
    
    return finalCoverageProjection;
  }

  /**
   * Calculate completion timeline
   * @param {number} topicsToComplete - Topics to complete
   * @param {Object} syllabusEstimate - Syllabus completion estimate
   * @param {number} monthsRemaining - Months remaining
   * @returns {Object} Completion timeline
   */
  calculateCompletionTimeline(topicsToComplete, syllabusEstimate, monthsRemaining) {
    const { estimatedTopicsPerDay } = syllabusEstimate;
    const daysNeeded = Math.ceil(topicsToComplete / estimatedTopicsPerDay);
    const monthsNeeded = Math.ceil(daysNeeded / 30);
    
    return {
      daysNeeded: daysNeeded,
      monthsNeeded: monthsNeeded,
      bufferTime: monthsRemaining - monthsNeeded,
      completionDate: this.calculateCompletionDate(daysNeeded),
      pacing: {
        daily: estimatedTopicsPerDay,
        weekly: Math.round(estimatedTopicsPerDay * 7 * 10) / 10,
        monthly: Math.round(estimatedTopicsPerDay * 30)
      }
    };
  }

  /**
   * Calculate completion date
   * @param {number} daysNeeded - Days needed
   * @returns {string} Completion date
   */
  calculateCompletionDate(daysNeeded) {
    const today = new Date();
    const completionDate = new Date(today.getTime() + (daysNeeded * 24 * 60 * 60 * 1000));
    return completionDate.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  }

  /**
   * Assess feasibility of completing remaining topics
   * @param {number} unexploredTopics - Unexplored topics
   * @param {number} maxTopicsCanCover - Max topics can cover
   * @returns {string} Feasibility assessment
   */
  assessFeasibility(unexploredTopics, maxTopicsCanCover) {
    const ratio = maxTopicsCanCover / unexploredTopics;
    
    if (ratio >= 1.2) {
      return 'excellent'; // Can cover all topics with time to spare
    } else if (ratio >= 1.0) {
      return 'achievable'; // Can cover all topics if consistent
    } else if (ratio >= 0.8) {
      return 'challenging'; // Can cover most topics with focus
    } else {
      return 'strategic'; // Need to prioritize high-yield topics only
    }
  }

  /**
   * Calculate coverage from database data
   * @param {Object} studentData - Student data
   * @param {Object} totalSyllabus - Total syllabus info
   * @returns {Object} Coverage analysis
   */
  calculateDatabaseCoverage(studentData, totalSyllabus) {
    const practicedChapters = studentData.practiced_chapter_names || [];
    const subjectNames = studentData.practiced_subject_names || [];
    
    // Map practiced chapters to subjects
    const subjectCoverage = {
      physics: { total: totalSyllabus.physics, covered: 0, percentage: 0 },
      chemistry: { total: totalSyllabus.chemistry, covered: 0, percentage: 0 },
      biology: { total: totalSyllabus.biology, covered: 0, percentage: 0 }
    };
    
    // Estimate coverage based on practiced chapters (simplified)
    const totalCovered = practicedChapters.length;
    const estimatedPhysics = Math.min(Math.floor(totalCovered * 0.35), totalSyllabus.physics);
    const estimatedChemistry = Math.min(Math.floor(totalCovered * 0.35), totalSyllabus.chemistry);
    const estimatedBiology = Math.min(Math.floor(totalCovered * 0.30), totalSyllabus.biology);
    
    subjectCoverage.physics.covered = estimatedPhysics;
    subjectCoverage.physics.percentage = (estimatedPhysics / totalSyllabus.physics * 100).toFixed(1);
    
    subjectCoverage.chemistry.covered = estimatedChemistry;
    subjectCoverage.chemistry.percentage = (estimatedChemistry / totalSyllabus.chemistry * 100).toFixed(1);
    
    subjectCoverage.biology.covered = estimatedBiology;
    subjectCoverage.biology.percentage = (estimatedBiology / totalSyllabus.biology * 100).toFixed(1);
    
    const totalCoveredTopics = estimatedPhysics + estimatedChemistry + estimatedBiology;
    const overallPercentage = (totalCoveredTopics / totalSyllabus.total * 100).toFixed(1);
    
    return {
      totalTopics: totalSyllabus.total,
      coveredTopics: totalCoveredTopics,
      coveragePercentage: parseFloat(overallPercentage),
      subjectWiseCoverage: subjectCoverage,
      strongTopics: studentData.strong_subtopics_names || [],
      weakTopics: studentData.weak_subtopics_names || [],
      unexploredTopics: this.calculateUnexploredTopics(totalCoveredTopics, totalSyllabus.total),
      practicedChapters: practicedChapters
    };
  }

  /**
   * Estimate coverage from preparation level
   * @param {string} preparationLevel - Preparation level
   * @param {Object} totalSyllabus - Total syllabus
   * @returns {Object} Estimated coverage
   */
  estimateCoverageFromLevel(preparationLevel, totalSyllabus) {
    let coverageMultiplier;
    
    switch (preparationLevel) {
      case 'fresh': coverageMultiplier = 0.05; break; // 5%
      case 'basic': coverageMultiplier = 0.25; break; // 25%
      case 'moderate': coverageMultiplier = 0.50; break; // 50%
      default: coverageMultiplier = 0.05;
    }
    
    const totalCovered = Math.floor(totalSyllabus.total * coverageMultiplier);
    const physicseCovered = Math.floor(totalSyllabus.physics * coverageMultiplier);
    const chemistryCovered = Math.floor(totalSyllabus.chemistry * coverageMultiplier);
    const biologyCovered = Math.floor(totalSyllabus.biology * coverageMultiplier);
    
    return {
      totalTopics: totalSyllabus.total,
      coveredTopics: totalCovered,
      coveragePercentage: parseFloat((coverageMultiplier * 100).toFixed(1)),
      subjectWiseCoverage: {
        physics: { 
          total: totalSyllabus.physics, 
          covered: physicseCovered, 
          percentage: (coverageMultiplier * 100).toFixed(1) 
        },
        chemistry: { 
          total: totalSyllabus.chemistry, 
          covered: chemistryCovered, 
          percentage: (coverageMultiplier * 100).toFixed(1) 
        },
        biology: { 
          total: totalSyllabus.biology, 
          covered: biologyCovered, 
          percentage: (coverageMultiplier * 100).toFixed(1) 
        }
      },
      strongTopics: [],
      weakTopics: [],
      unexploredTopics: this.calculateUnexploredTopics(totalCovered, totalSyllabus.total)
    };
  }

  /**
   * Calculate unexplored topics count
   * @param {number} coveredTopics - Covered topics
   * @param {number} totalTopics - Total topics
   * @returns {number} Unexplored topics count
   */
  calculateUnexploredTopics(coveredTopics, totalTopics) {
    return Math.max(0, totalTopics - coveredTopics);
  }

  /**
   * Get default coverage for error cases
   * @returns {Object} Default coverage
   */
  getDefaultCoverage() {
    return {
      totalTopics: 150,
      coveredTopics: 5,
      coveragePercentage: 3.3,
      subjectWiseCoverage: {
        physics: { total: 50, covered: 2, percentage: 4.0 },
        chemistry: { total: 50, covered: 2, percentage: 4.0 },
        biology: { total: 50, covered: 1, percentage: 2.0 }
      },
      strongTopics: [],
      weakTopics: [],
      unexploredTopics: 145,
      priorityTopics: []
    };
  }

  /**
   * Build time assessment response
   * @param {number} hoursPerDay - Hours per day
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} academicContext - Academic context
   * @returns {string} Response message
   */
  buildTimeAssessmentResponse(hoursPerDay, studyCapacity, academicContext) {
    const { syllabusCompletionEstimate, completionProjection } = studyCapacity;
    
    return `Perfect! **${hoursPerDay} hours per day** is ${studyCapacity.recommendation}

**📊 Your Study Capacity Analysis:**
🕒 **Total study time:** ${studyCapacity.totalHours} hours over ${studyCapacity.monthsRemaining} months
📈 **Capacity level:** ${studyCapacity.capacity} (${syllabusCompletionEstimate.qualityLevel} approach)

**🎯 Syllabus Completion Projection:**
📚 **Topics you can master:** ${syllabusCompletionEstimate.maxTopicsCanCover} out of 150 NEET topics (${completionProjection.percentage}%)
📅 **Daily topic target:** ${syllabusCompletionEstimate.estimatedTopicsPerDay} topics/day

**📊 Subject-wise Coverage Potential:**
• **Physics:** ${completionProjection.physics}/50 topics (${Math.round(completionProjection.physics/50*100)}%)
• **Chemistry:** ${completionProjection.chemistry}/50 topics (${Math.round(completionProjection.chemistry/50*100)}%) 
• **Biology:** ${completionProjection.biology}/50 topics (${Math.round(completionProjection.biology/50*100)}%)

**⏰ Daily Time Distribution:**
• **New Topics:** ${syllabusCompletionEstimate.timeAllocation.newTopics} hrs (60%) 
• **Practice:** ${syllabusCompletionEstimate.timeAllocation.practice} hrs (25%)
• **Revision:** ${syllabusCompletionEstimate.timeAllocation.revision} hrs (15%)

**💡 What this means:** With ${hoursPerDay} hours daily, you can realistically achieve ${completionProjection.percentage}% syllabus coverage using a ${syllabusCompletionEstimate.qualityLevel} study approach. ${this.getCompletionInsight(completionProjection.percentage)}

Now let's understand your current preparation level to optimize this plan further.`;
  }

  /**
   * Get insight based on completion percentage
   * @param {number} completionPercentage - Completion percentage
   * @returns {string} Insight message
   */
  getCompletionInsight(completionPercentage) {
    if (completionPercentage >= 95) {
      return "This gives you excellent coverage with time for multiple revisions!";
    } else if (completionPercentage >= 80) {
      return "This covers most high-weightage topics with good revision time.";
    } else if (completionPercentage >= 60) {
      return "This covers essential topics - we'll prioritize high-yield areas for maximum impact.";
    } else {
      return "We'll focus strategically on the highest-scoring topics to maximize your potential.";
    }
  }

  /**
   * Build syllabus analysis response
   * @param {Object} syllabusAnalysis - Syllabus analysis
   * @param {Object} academicContext - Academic context
   * @returns {string} Response message
   */
  buildSyllabusAnalysisResponse(syllabusAnalysis, academicContext) {
    const { 
      coveragePercentage, 
      totalTopics, 
      coveredTopics, 
      subjectWiseCoverage, 
      unexploredTopics,
      timeBasedProjection 
    } = syllabusAnalysis;
    
    let response = `**📚 Your NEET Syllabus Analysis:**

**📊 Current Status:**
• **Overall Coverage:** ${coveragePercentage}% (${coveredTopics}/${totalTopics} topics completed)

**📖 Subject-wise Current Coverage:**
• **Physics:** ${subjectWiseCoverage.physics.percentage}% (${subjectWiseCoverage.physics.covered}/${subjectWiseCoverage.physics.total} topics)
• **Chemistry:** ${subjectWiseCoverage.chemistry.percentage}% (${subjectWiseCoverage.chemistry.covered}/${subjectWiseCoverage.chemistry.total} topics)
• **Biology:** ${subjectWiseCoverage.biology.percentage}% (${subjectWiseCoverage.biology.covered}/${subjectWiseCoverage.biology.total} topics)

🎯 **Remaining Opportunity:** ${unexploredTopics} topics yet to explore`;

    // Add time-based projection if available
    if (timeBasedProjection) {
      response += `

**⏰ Time-Based Completion Projection:**
📈 **What you can achieve:** ${timeBasedProjection.finalProjectedCoverage}% total coverage
📊 **Additional coverage possible:** +${timeBasedProjection.additionalCoverageInTimeframe}% (${timeBasedProjection.topicsWeCanComplete} topics)
🎯 **Feasibility:** ${timeBasedProjection.feasibilityAssessment} - ${this.getFeasibilityMessage(timeBasedProjection.feasibilityAssessment)}

**📅 Completion Timeline:**
• **Topics per day:** ${timeBasedProjection.completionTimeline.pacing.daily}
• **Completion target:** ${timeBasedProjection.completionTimeline.completionDate}
• **Buffer time:** ${Math.max(timeBasedProjection.completionTimeline.bufferTime, 0)} months for revision`;
    }

    response += `

**💡 Strategic Insight:** ${this.getStrategicInsight(coveragePercentage, timeBasedProjection)}

Based on this analysis and your available study time, I'm now creating a **personalized, step-by-step study plan** that will maximize your NEET score. Let me put together your complete preparation roadmap...`;

    return response;
  }

  /**
   * Get feasibility message
   * @param {string} feasibility - Feasibility level
   * @returns {string} Feasibility message
   */
  getFeasibilityMessage(feasibility) {
    switch (feasibility) {
      case 'excellent':
        return 'You can complete all remaining topics with time for multiple revisions!';
      case 'achievable':
        return 'All remaining topics can be covered if you stay consistent with your schedule.';
      case 'challenging':
        return 'Most topics can be covered, but you\'ll need to stay focused and efficient.';
      case 'strategic':
        return 'Focus on high-weightage topics for maximum score impact.';
      default:
        return 'We\'ll optimize your study strategy based on available time.';
    }
  }

  /**
   * Get strategic insight based on coverage and time projection
   * @param {number} currentCoverage - Current coverage percentage
   * @param {Object} timeProjection - Time-based projection
   * @returns {string} Strategic insight
   */
  getStrategicInsight(currentCoverage, timeProjection) {
    if (!timeProjection) {
      return "With your available time, we'll create an optimized study plan for maximum impact.";
    }

    const finalCoverage = timeProjection.finalProjectedCoverage;
    const feasibility = timeProjection.feasibilityAssessment;

    if (currentCoverage < 10 && finalCoverage >= 80) {
      return "Starting fresh gives you a clean slate to build strong foundations and achieve excellent coverage!";
    } else if (currentCoverage < 30 && finalCoverage >= 70) {
      return "You have excellent potential to build comprehensive NEET preparation with your available time.";
    } else if (feasibility === 'strategic') {
      return "We'll focus on the highest-scoring 20% of topics that typically yield 80% of NEET marks.";
    } else if (timeProjection.completionTimeline.bufferTime > 2) {
      return "Great news! You have sufficient time for complete coverage plus extensive revision and practice.";
    } else {
      return "Your timeline is tight but achievable - we'll prioritize efficiently for maximum score impact.";
    }
  }

  /**
   * Create comprehensive study plan with specific topics and timelines
   * @param {Object} motivationalContext - Motivational context
   * @param {number} dailyStudyHours - Daily study hours
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} syllabusAnalysis - Syllabus analysis
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Comprehensive study plan
   */
  async createComprehensiveStudyPlan(motivationalContext, dailyStudyHours, studyCapacity, syllabusAnalysis, academicContext) {
    const { classLevel } = motivationalContext;
    const { neetExamMonthsRemaining } = academicContext;
    
    // Check if Class 12 student needs foundation recovery
    let foundationRecoveryPlan = null;
    if (classLevel === '12' && syllabusAnalysis.weakTopics && syllabusAnalysis.weakTopics.length > 0) {
      foundationRecoveryPlan = await this.knowledgeBase.generateFoundationRecoveryPlan(
        syllabusAnalysis.weakTopics,
        classLevel
      );
      console.log(`📚 Foundation recovery plan generated: ${foundationRecoveryPlan.criticalClass11Chapters.length} Class 11 chapters identified`);
    }
    
    // Create intelligent topic selection and scheduling with cross-class correlations
    const topicSelectionStrategy = await this.createIntelligentTopicSelection(
      syllabusAnalysis,
      studyCapacity,
      motivationalContext,
      academicContext,
      foundationRecoveryPlan
    );
    
    // Generate detailed timeline with specific topics
    const detailedTimeline = await this.generateDetailedTopicTimeline(
      topicSelectionStrategy,
      studyCapacity,
      academicContext
    );
    
    // Create complementary topic clusters for parallel learning with cross-class correlations
    const complementaryTopicClusters = this.createComplementaryTopicClusters(
      topicSelectionStrategy.selectedTopics,
      studyCapacity,
      foundationRecoveryPlan
    );
    
    // Generate enhanced study techniques for weak topics
    const studyTechniques = await this.generateStudyTechniques(
      syllabusAnalysis,
      topicSelectionStrategy.selectedTopics,
      motivationalContext
    );

    const studyPlan = {
      overview: {
        classLevel: classLevel,
        dailyHours: dailyStudyHours,
        monthsRemaining: neetExamMonthsRemaining.months,
        totalHours: studyCapacity.totalHours,
        capacityLevel: studyCapacity.capacity,
        topicSelectionStrategy: topicSelectionStrategy.strategy,
        totalTopicsPlanned: topicSelectionStrategy.selectedTopics.length,
        foundationRecoveryRequired: foundationRecoveryPlan?.foundationRequired || false,
        class11ChaptersNeeded: foundationRecoveryPlan?.criticalClass11Chapters?.length || 0
      },
      intelligentTopicSelection: topicSelectionStrategy,
      detailedTimeline: detailedTimeline,
      complementaryTopicClusters: complementaryTopicClusters,
      foundationRecoveryPlan: foundationRecoveryPlan,
      dailyScheduleWithTopics: this.createTopicSpecificDailySchedule(detailedTimeline, dailyStudyHours),
      weeklyMilestones: this.createWeeklyTopicMilestones(detailedTimeline),
      monthlyGoals: this.createMonthlyTopicGoals(detailedTimeline),
      studyStrategy: this.createAdvancedStudyStrategy(topicSelectionStrategy, studyCapacity),
      practiceSchedule: this.createTopicSpecificPracticeSchedule(detailedTimeline, studyCapacity),
      revisionPlan: this.createTopicSpecificRevisionPlan(detailedTimeline, studyCapacity),
      motivationalSupport: this.createMotivationalSupport(motivationalContext, academicContext),
      studyTechniques: studyTechniques // NEW: Mind maps, mnemonics, visual aids
    };
    
    return studyPlan;
  }

  /**
   * Create intelligent topic selection using Claude API with proper prompt engineering
   * @param {Object} syllabusAnalysis - Syllabus analysis
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} motivationalContext - Motivational context
   * @param {Object} academicContext - Academic context
   * @param {Object} foundationRecoveryPlan - Cross-class correlation recovery plan
   * @returns {Promise<Object>} Topic selection strategy
   */
  async createIntelligentTopicSelection(syllabusAnalysis, studyCapacity, motivationalContext, academicContext, foundationRecoveryPlan = null) {
    try {
      // Get all NEET chapters from knowledge base
      const allChapters = await this.getAllNEETChapters();
      
      // Use Claude API to make intelligent topic selection decisions with foundation recovery
      const topicSelectionPrompt = this.buildTopicSelectionPrompt(
        allChapters,
        syllabusAnalysis,
        studyCapacity,
        motivationalContext,
        academicContext,
        foundationRecoveryPlan
      );
      
      const claudeResponse = await this.llmService.callClaudeAPI(topicSelectionPrompt, {
        temperature: 0.3, // Lower temperature for more consistent topic selection
        max_tokens: 2000
      });
      
      // Parse Claude's response and structure it
      const intelligentSelection = this.parseTopicSelectionResponse(claudeResponse, allChapters);
      
      return {
        strategy: intelligentSelection.strategy,
        reasoning: intelligentSelection.reasoning,
        totalAvailableTopics: allChapters.length,
        selectedTopics: intelligentSelection.selectedTopics,
        priorityBreakdown: intelligentSelection.priorityBreakdown,
        studentDataIntegration: intelligentSelection.studentDataIntegration,
        claudeRecommendations: intelligentSelection.recommendations
      };
    } catch (error) {
      console.error('❌ Failed to create intelligent topic selection:', error.message);
      // Fallback to basic selection if Claude API fails
      return this.createFallbackTopicSelection(syllabusAnalysis, studyCapacity, academicContext);
    }
  }

  /**
   * Build comprehensive prompt for Claude API topic selection
   * @param {Array} allChapters - All NEET chapters
   * @param {Object} syllabusAnalysis - Syllabus analysis
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} motivationalContext - Motivational context
   * @param {Object} academicContext - Academic context
   * @param {Object} foundationRecoveryPlan - Cross-class correlation recovery plan
   * @returns {string} Structured prompt for Claude
   */
  buildTopicSelectionPrompt(allChapters, syllabusAnalysis, studyCapacity, motivationalContext, academicContext, foundationRecoveryPlan = null) {
    return `You are an expert NEET preparation strategist. Create a personalized topic selection and study timeline for a student based on their specific situation.

## STUDENT PROFILE:
- **Class Level:** ${motivationalContext.classLevel}
- **Daily Study Hours:** ${studyCapacity.dailyHours} hours
- **Months Remaining:** ${academicContext.neetExamMonthsRemaining.months} months
- **Study Capacity:** ${studyCapacity.capacity}
- **Emotional State:** ${motivationalContext.emotionalState}

## CURRENT PREPARATION STATUS:
- **Syllabus Coverage:** ${syllabusAnalysis.coveragePercentage}%
- **Database Weak Topics:** ${(syllabusAnalysis.weakTopics || []).join(', ') || 'None identified'}
- **Database Strong Topics:** ${(syllabusAnalysis.strongTopics || []).join(', ') || 'None identified'}
- **Practiced Chapters:** ${(syllabusAnalysis.practicedChapters || []).slice(0, 10).join(', ') || 'None yet'}

## NEET SCORE-BASED ANALYSIS (22.7 Lakh Students Research):
${this.buildNeetAnalysisSection(motivationalContext, syllabusAnalysis)}

## AVAILABLE NEET CHAPTERS (with weightage & difficulty):
${allChapters.slice(0, 50).map(chapter => 
  `- **${chapter.name}** (${chapter.subject}, Class ${chapter.classLevel}) - Weightage: ${chapter.weightage}%, Difficulty: ${chapter.difficulty}, Questions: ${chapter.expectedQuestions}`
).join('\n')}

## STUDY CAPACITY ANALYSIS:
- **Total Hours Available:** ${studyCapacity.totalHours} hours
- **Topics Can Realistically Cover:** ${studyCapacity.syllabusCompletionEstimate?.maxTopicsCanCover || 'Calculate based on time'}
- **Daily Topic Target:** ${studyCapacity.topicsPerDay || 'Calculate based on time'} topics/day
- **Quality Level:** ${studyCapacity.syllabusCompletionEstimate?.qualityLevel || 'standard'}

${foundationRecoveryPlan ? this.buildFoundationRecoverySection(foundationRecoveryPlan) : ''}

## YOUR TASK:
Create a comprehensive, specific study plan with the following requirements:

1. **INTELLIGENT TOPIC SELECTION:**
   - Select exactly the right number of topics for available time
   - Prioritize student's weak areas heavily (from database analysis)
   - Include high-weightage NEET topics
   - Balance difficulty based on study capacity
   - Consider prerequisite dependencies
   - If foundation recovery plan exists, prioritize critical Class 11 chapters FIRST

2. **SPECIFIC TIMELINE WITH EXACT TOPICS:**
   - Provide specific topics for next 30 days with exact dates
   - Account for topic difficulty and time requirements
   - Group complementary topics for parallel learning
   - Consider optimal study sequence
   - Use foundation recovery plan for parallel Class 11/12 study

3. **STUDENT-SPECIFIC ADAPTATIONS:**
   - Address emotional state (beginner/overwhelmed needs encouragement)
   - Balance weak area focus with confidence building
   - Suggest parallel learning for efficiency
   - For Class 12 students: study critical Class 11 foundations BEFORE related Class 12 topics

## RESPONSE FORMAT (JSON):
{
  "strategy": "Strategic approach name",
  "reasoning": "Why this approach suits the student",
  "selectedTopics": [
    {
      "topicName": "Exact chapter name",
      "subject": "physics/chemistry/biology",
      "classLevel": "11/12",
      "priority": "Critical/High/Medium",
      "daysRequired": 2,
      "startDate": "Date in MM/DD format",
      "endDate": "Date in MM/DD format",
      "reason": "Why selected for this student",
      "complementaryTopics": ["Related topic 1", "Related topic 2"],
      "studentRelevance": "How it addresses student's weak/strong areas"
    }
  ],
  "priorityBreakdown": {
    "critical": 8,
    "high": 12,
    "medium": 5
  },
  "studentDataIntegration": {
    "weakTopicsAddressed": 6,
    "strongTopicsReinforced": 2,
    "balancingStrategy": "Explanation of how weak/strong areas are balanced"
  },
  "weeklySchedule": [
    {
      "week": 1,
      "topics": ["Topic 1", "Topic 2"],
      "focus": "Foundation building",
      "weeklyGoal": "Specific measurable goal"
    }
  ],
  "complementaryLearning": [
    {
      "cluster": "Related topics that should be studied together",
      "benefit": "Why studying these together helps",
      "sequence": "Order to study them"
    }
  ],
  "recommendations": [
    "Specific actionable recommendation 1",
    "Specific actionable recommendation 2"
  ]
}

Create a realistic, achievable plan that maximizes NEET score potential while being encouraging for a ${motivationalContext.emotionalState} ${motivationalContext.classLevel} student.`;
  }

  /**
   * Build NEET analysis section for prompt
   * @param {Object} motivationalContext - Motivational context
   * @param {Object} syllabusAnalysis - Syllabus analysis
   * @returns {string} NEET analysis section
   */
  buildNeetAnalysisSection(motivationalContext, syllabusAnalysis) {
    if (!motivationalContext.isDropper || !motivationalContext.hasNeetScore) {
      return '- **Student Type:** Fresh attempt student - using general weak spot patterns\n- **Research Basis:** Will use performance database + high-weightage topic analysis';
    }

    // Try to get weak spots analysis from conversation state
    let neetWeakSpots = null;
    try {
      // This will be available if the analysis was loaded in handleMotivationalFlow
      const conversationStates = Array.from(this.conversationStates.values());
      const currentState = conversationStates.find(state => state.motivationalContext?.neetScore === motivationalContext.neetScore);
      neetWeakSpots = currentState?.neetWeakSpotsAnalysis;
    } catch (error) {
      console.warn('Could not retrieve NEET weak spots from conversation state');
    }

    if (!neetWeakSpots) {
      return `- **Previous NEET Score:** ${motivationalContext.neetScore}/720
- **Student Type:** Dropper with score data available
- **Research Integration:** Will apply 22.7 lakh student analysis for this score range`;
    }

    const physicsWeakSpots = neetWeakSpots.overallWeakSpots?.filter(spot => spot.subject === 'Physics').slice(0, 3) || [];
    const chemistryWeakSpots = neetWeakSpots.overallWeakSpots?.filter(spot => spot.subject === 'Chemistry').slice(0, 3) || [];
    const biologyWeakSpots = neetWeakSpots.overallWeakSpots?.filter(spot => spot.subject === 'Biology').slice(0, 3) || [];

    return `- **Previous NEET Score:** ${motivationalContext.neetScore}/720
- **Score Category:** ${neetWeakSpots.category} (${neetWeakSpots.scoreRange})
- **Percentile Range:** ${neetWeakSpots.percentile}
- **AIR Range:** ${neetWeakSpots.airRank}
- **Intervention Priority:** ${neetWeakSpots.interventionPriority.toUpperCase()}

### Research-Based Weak Spots for This Score Range:
**Physics:** ${physicsWeakSpots.map(spot => spot.topic).join(', ') || 'No specific patterns identified'}
**Chemistry:** ${chemistryWeakSpots.map(spot => spot.topic).join(', ') || 'No specific patterns identified'}
**Biology:** ${biologyWeakSpots.map(spot => spot.topic).join(', ') || 'No specific patterns identified'}

### Strategic Approach: ${neetWeakSpots.studyRecommendations?.overall?.strategicApproach || 'Balanced improvement across all subjects'}`;
  }

  /**
   * Parse Claude's topic selection response
   * @param {string} claudeResponse - Raw response from Claude
   * @param {Array} allChapters - All available chapters for reference
   * @returns {Object} Parsed topic selection
   */
  parseTopicSelectionResponse(claudeResponse, allChapters) {
    try {
      // Extract text from Claude API response format
      const responseText = claudeResponse.content?.[0]?.text || claudeResponse.content || claudeResponse.text || claudeResponse;
      
      // Try to extract JSON from Claude's response
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON found in Claude response');
      }
      
      const parsedResponse = JSON.parse(jsonMatch[0]);
      
      // Validate and enrich the response
      const enrichedTopics = parsedResponse.selectedTopics.map(topic => {
        // Find matching chapter from knowledge base
        const matchingChapter = allChapters.find(chapter => 
          chapter.name.toLowerCase().includes(topic.topicName.toLowerCase()) ||
          topic.topicName.toLowerCase().includes(chapter.name.toLowerCase())
        );
        
        return {
          ...topic,
          chapterData: matchingChapter,
          id: matchingChapter?.id || `custom_${Math.random().toString(36).substr(2, 9)}`,
          weightage: matchingChapter?.weightage || 3,
          difficulty: matchingChapter?.difficulty || topic.difficulty || 'Medium',
          topics: matchingChapter?.topics || [topic.topicName],
          selectionRank: topic.priority === 'Critical' ? 1 : topic.priority === 'High' ? 2 : 3
        };
      });
      
      return {
        strategy: parsedResponse.strategy,
        reasoning: parsedResponse.reasoning,
        selectedTopics: enrichedTopics,
        priorityBreakdown: parsedResponse.priorityBreakdown,
        studentDataIntegration: parsedResponse.studentDataIntegration,
        weeklySchedule: parsedResponse.weeklySchedule,
        complementaryLearning: parsedResponse.complementaryLearning,
        recommendations: parsedResponse.recommendations
      };
    } catch (error) {
      console.error('❌ Failed to parse Claude topic selection response:', error.message);
      console.log('Raw Claude response:', claudeResponse);
      console.log('Extracted text:', claudeResponse.content?.[0]?.text || claudeResponse.content || claudeResponse.text || claudeResponse);
      throw error;
    }
  }

  /**
   * Get all NEET chapters from knowledge base
   * @returns {Promise<Array>} All NEET chapters
   */
  async getAllNEETChapters() {
    try {
      const syllabusData = await this.knowledgeBase.loadSyllabusData();
      const allChapters = [];
      
      // Combine all chapters from all subjects and classes
      ['physics', 'chemistry', 'biology'].forEach(subject => {
        ['11', '12'].forEach(classLevel => {
          const chapters = syllabusData.subjects[subject][`class${classLevel}`]?.chapters || [];
          chapters.forEach(chapter => {
            allChapters.push({
              ...chapter,
              subject: subject,
              classLevel: classLevel,
              fullId: `${subject}_${classLevel}_${chapter.id}`
            });
          });
        });
      });
      
      return allChapters;
    } catch (error) {
      console.error('❌ Failed to get NEET chapters:', error.message);
      return this.getFallbackChapters();
    }
  }

  /**
   * Calculate priority scores for each topic
   * @param {Array} allChapters - All NEET chapters
   * @param {Array} studentWeakTopics - Student's weak topics
   * @param {Array} studentStrongTopics - Student's strong topics
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} academicContext - Academic context
   * @returns {Array} Chapters with priority scores
   */
  calculateTopicPriorityScores(allChapters, studentWeakTopics, studentStrongTopics, studyCapacity, academicContext) {
    return allChapters.map(chapter => {
      let priorityScore = 0;
      const reasons = [];
      
      // Base weightage score (0-40 points)
      const weightageScore = (chapter.weightage || 3) * 4;
      priorityScore += weightageScore;
      reasons.push(`Weightage: ${chapter.weightage}% (+${weightageScore})`);
      
      // High weightage bonus (0-20 points)
      if (chapter.highWeightage) {
        priorityScore += 20;
        reasons.push('High weightage topic (+20)');
      }
      
      // Student weakness penalty/bonus (-10 to +30 points)
      const topicName = chapter.name;
      if (studentWeakTopics.some(weak => weak.toLowerCase().includes(topicName.toLowerCase()))) {
        priorityScore += 30; // Prioritize weak areas heavily
        reasons.push('Student weak area (+30)');
      } else if (studentStrongTopics.some(strong => strong.toLowerCase().includes(topicName.toLowerCase()))) {
        if (studyCapacity.capacity === 'challenging') {
          priorityScore -= 10; // Skip strong areas if time is limited
          reasons.push('Student strong area, time limited (-10)');
        } else {
          priorityScore += 5; // Reinforce strong areas if time permits
          reasons.push('Student strong area, reinforce (+5)');
        }
      }
      
      // Difficulty adjustment based on capacity (-15 to +10 points)
      const difficultyAdjustment = this.getDifficultyAdjustment(chapter.difficulty, studyCapacity.capacity);
      priorityScore += difficultyAdjustment.score;
      reasons.push(difficultyAdjustment.reason);
      
      // Prerequisites consideration (-5 to +15 points)
      const prerequisiteScore = this.getPrerequisiteScore(chapter, allChapters, studentStrongTopics);
      priorityScore += prerequisiteScore.score;
      if (prerequisiteScore.reason) reasons.push(prerequisiteScore.reason);
      
      // Time remaining adjustment (-10 to +15 points)
      const timeAdjustment = this.getTimeBasedAdjustment(chapter, academicContext);
      priorityScore += timeAdjustment.score;
      reasons.push(timeAdjustment.reason);
      
      return {
        ...chapter,
        priorityScore: Math.max(0, priorityScore), // Ensure non-negative
        scoringReasons: reasons,
        selectionCategory: this.determineSelectionCategory(priorityScore)
      };
    }).sort((a, b) => b.priorityScore - a.priorityScore);
  }

  /**
   * Get difficulty adjustment based on study capacity
   * @param {string} difficulty - Chapter difficulty
   * @param {string} capacity - Study capacity
   * @returns {Object} Difficulty adjustment
   */
  getDifficultyAdjustment(difficulty, capacity) {
    const adjustments = {
      'challenging': {
        'Easy': { score: 10, reason: 'Easy topic, time limited (+10)' },
        'Medium': { score: 0, reason: 'Medium difficulty (0)' },
        'Hard': { score: -15, reason: 'Hard topic, skip for now (-15)' }
      },
      'moderate': {
        'Easy': { score: 5, reason: 'Easy topic (+5)' },
        'Medium': { score: 5, reason: 'Medium difficulty (+5)' },
        'Hard': { score: -5, reason: 'Hard topic, careful selection (-5)' }
      },
      'good': {
        'Easy': { score: 5, reason: 'Easy topic (+5)' },
        'Medium': { score: 10, reason: 'Medium difficulty, good fit (+10)' },
        'Hard': { score: 5, reason: 'Hard topic, manageable (+5)' }
      },
      'excellent': {
        'Easy': { score: 0, reason: 'Easy topic (0)' },
        'Medium': { score: 5, reason: 'Medium difficulty (+5)' },
        'Hard': { score: 10, reason: 'Hard topic, time available (+10)' }
      }
    };
    
    return adjustments[capacity]?.[difficulty] || { score: 0, reason: 'Standard difficulty (0)' };
  }

  /**
   * Get prerequisite score for topic
   * @param {Object} chapter - Chapter object
   * @param {Array} allChapters - All chapters
   * @param {Array} studentStrongTopics - Student strong topics
   * @returns {Object} Prerequisite score
   */
  getPrerequisiteScore(chapter, allChapters, studentStrongTopics) {
    if (!chapter.prerequisites || chapter.prerequisites.length === 0) {
      return { score: 0, reason: null };
    }
    
    const prerequisitesMet = chapter.prerequisites.filter(prereq =>
      studentStrongTopics.some(strong => strong.toLowerCase().includes(prereq.toLowerCase())) ||
      allChapters.some(ch => ch.name.toLowerCase().includes(prereq.toLowerCase()) && ch.priorityScore > 50)
    ).length;
    
    const totalPrerequisites = chapter.prerequisites.length;
    const prerequisiteRatio = prerequisitesMet / totalPrerequisites;
    
    if (prerequisiteRatio >= 0.8) {
      return { score: 15, reason: 'Prerequisites mostly met (+15)' };
    } else if (prerequisiteRatio >= 0.5) {
      return { score: 5, reason: 'Some prerequisites met (+5)' };
    } else {
      return { score: -5, reason: 'Prerequisites not met (-5)' };
    }
  }

  /**
   * Get time-based adjustment
   * @param {Object} chapter - Chapter object
   * @param {Object} academicContext - Academic context
   * @returns {Object} Time adjustment
   */
  getTimeBasedAdjustment(chapter, academicContext) {
    const monthsRemaining = academicContext.neetExamMonthsRemaining.months;
    
    if (monthsRemaining <= 3) {
      // Very limited time - focus on high-yield only
      if (chapter.expectedQuestions >= 2) {
        return { score: 15, reason: 'High yield, urgent timeline (+15)' };
      } else {
        return { score: -10, reason: 'Low yield, urgent timeline (-10)' };
      }
    } else if (monthsRemaining <= 6) {
      // Moderate time - balanced approach
      if (chapter.highWeightage) {
        return { score: 10, reason: 'High weightage, moderate time (+10)' };
      } else {
        return { score: 0, reason: 'Standard time allocation (0)' };
      }
    } else {
      // Plenty of time - comprehensive approach
      return { score: 5, reason: 'Sufficient time available (+5)' };
    }
  }

  /**
   * Determine selection category based on priority score
   * @param {number} priorityScore - Priority score
   * @returns {string} Selection category
   */
  determineSelectionCategory(priorityScore) {
    if (priorityScore >= 80) return 'Critical';
    if (priorityScore >= 60) return 'High Priority';
    if (priorityScore >= 40) return 'Medium Priority';
    if (priorityScore >= 20) return 'Low Priority';
    return 'Skip';
  }

  /**
   * Select optimal topics based on capacity and time
   * @param {Array} prioritizedTopics - Topics with priority scores
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} academicContext - Academic context
   * @returns {Array} Selected topics
   */
  selectOptimalTopics(prioritizedTopics, studyCapacity, academicContext) {
    const maxTopicsCanCover = studyCapacity.syllabusCompletionEstimate.maxTopicsCanCover;
    const monthsRemaining = academicContext.neetExamMonthsRemaining.months;
    
    let selectedTopics = [];
    let totalTimeRequired = 0;
    const timePerTopic = studyCapacity.syllabusCompletionEstimate.timeAllocation.newTopics;
    
    // Always include critical topics
    const criticalTopics = prioritizedTopics.filter(topic => topic.selectionCategory === 'Critical');
    selectedTopics.push(...criticalTopics.slice(0, Math.floor(maxTopicsCanCover * 0.4)));
    
    // Add high priority topics
    const highPriorityTopics = prioritizedTopics.filter(topic => topic.selectionCategory === 'High Priority');
    const remainingSlots = maxTopicsCanCover - selectedTopics.length;
    selectedTopics.push(...highPriorityTopics.slice(0, Math.floor(remainingSlots * 0.6)));
    
    // Fill remaining slots with medium priority if time permits
    if (studyCapacity.capacity !== 'challenging') {
      const mediumPriorityTopics = prioritizedTopics.filter(topic => topic.selectionCategory === 'Medium Priority');
      const finalRemainingSlots = maxTopicsCanCover - selectedTopics.length;
      selectedTopics.push(...mediumPriorityTopics.slice(0, finalRemainingSlots));
    }
    
    // Add metadata to each selected topic
    return selectedTopics.map((topic, index) => ({
      ...topic,
      selectionRank: index + 1,
      estimatedDaysToComplete: this.calculateTopicCompletionDays(topic, studyCapacity),
      complementaryTopics: this.findComplementaryTopics(topic, prioritizedTopics),
      studyPhase: this.determineStudyPhase(index, selectedTopics.length, monthsRemaining)
    }));
  }

  /**
   * Generate detailed topic timeline using Claude API for intelligent scheduling
   * @param {Object} topicSelectionStrategy - Topic selection strategy
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Object>} Detailed timeline
   */
  async generateDetailedTopicTimeline(topicSelectionStrategy, studyCapacity, academicContext) {
    try {
      // Use Claude API to create intelligent timeline and daily breakdowns
      const timelinePrompt = this.buildTimelineGenerationPrompt(
        topicSelectionStrategy,
        studyCapacity,
        academicContext
      );
      
      const claudeResponse = await this.llmService.callClaudeAPI(timelinePrompt, {
        temperature: 0.2, // Very low temperature for consistent scheduling
        max_tokens: 3000
      });
      
      // Parse Claude's timeline response
      const intelligentTimeline = this.parseTimelineResponse(claudeResponse, topicSelectionStrategy);
      
      return intelligentTimeline;
    } catch (error) {
      console.error('❌ Failed to generate intelligent timeline:', error.message);
      // Fallback to basic timeline generation
      return this.createBasicTimeline(topicSelectionStrategy, studyCapacity, academicContext);
    }
  }

  /**
   * Build prompt for Claude API timeline generation
   * @param {Object} topicSelectionStrategy - Topic selection strategy
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} academicContext - Academic context
   * @returns {string} Timeline generation prompt
   */
  buildTimelineGenerationPrompt(topicSelectionStrategy, studyCapacity, academicContext) {
    const startDate = new Date();
    const { selectedTopics } = topicSelectionStrategy;
    
    return `You are an expert NEET study scheduler. Create a detailed daily study timeline with specific dates, daily breakdowns, and complementary learning sequences.

## SELECTED TOPICS TO SCHEDULE:
${selectedTopics.map((topic, index) => 
  `${index + 1}. **${topic.topicName}** (${topic.subject}, Class ${topic.classLevel})
   - Priority: ${topic.priority}
   - Days Required: ${topic.daysRequired}
   - Reason: ${topic.reason}
   - Complementary: ${topic.complementaryTopics?.join(', ') || 'None'}
   - Student Relevance: ${topic.studentRelevance}`
).join('\n\n')}

## STUDY PARAMETERS:
- **Start Date:** ${startDate.toLocaleDateString('en-US')}
- **Daily Hours:** ${studyCapacity.dailyHours}
- **Study Quality:** ${studyCapacity.syllabusCompletionEstimate?.qualityLevel || 'standard'}
- **Time Distribution:** ${studyCapacity.syllabusCompletionEstimate?.timeAllocation?.newTopics || 60}% new topics, ${studyCapacity.syllabusCompletionEstimate?.timeAllocation?.practice || 25}% practice, ${studyCapacity.syllabusCompletionEstimate?.timeAllocation?.revision || 15}% revision

## YOUR TASK:
Create a comprehensive daily study schedule with the following requirements:

1. **OPTIMAL SEQUENCING:**
   - Arrange topics in the most logical learning sequence
   - Group complementary topics for parallel learning
   - Consider prerequisite dependencies
   - Balance subject rotation for better retention

2. **DAILY BREAKDOWNS:**
   - Provide specific subtopics for each day
   - Include exact time allocation (theory/practice/revision)
   - Set clear daily objectives and assessment criteria
   - Suggest specific resources and practice problems

3. **SMART SCHEDULING:**
   - Account for difficulty progression
   - Include buffer days for challenging topics
   - Plan review sessions between related topics
   - Consider weekly and monthly milestones

## RESPONSE FORMAT (JSON):
{
  "overview": {
    "totalTopics": ${selectedTopics.length},
    "startDate": "${startDate.toLocaleDateString('en-US')}",
    "estimatedCompletionDate": "MM/DD/YYYY",
    "totalDays": 0
  },
  "dailySchedule": [
    {
      "day": 1,
      "date": "MM/DD/YYYY",
      "mainTopic": "Primary topic for the day",
      "subject": "physics/chemistry/biology",
      "subtopics": ["Specific subtopic 1", "Specific subtopic 2"],
      "timeAllocation": {
        "theory": "2.5 hours",
        "practice": "1.0 hours", 
        "revision": "0.5 hours"
      },
      "objectives": ["Learn concept X", "Solve Y problems", "Understand Z"],
      "resources": ["NCERT Chapter", "HC Verma Problems", "Previous year questions"],
      "practice": ["10 numerical problems", "5 conceptual questions"],
      "assessment": ["Self-test criteria", "Success metrics"],
      "complementaryLearning": "Optional parallel topic to review",
      "nextDayPrep": "What to prepare for tomorrow"
    }
  ],
  "weeklyMilestones": [
    {
      "week": 1,
      "startDate": "MM/DD/YYYY",
      "endDate": "MM/DD/YYYY", 
      "topics": ["Topic 1", "Topic 2"],
      "focusArea": "Foundation building / Concept mastery / Problem solving",
      "weeklyGoal": "Specific measurable goal for the week",
      "assessment": "Weekly assessment plan"
    }
  ],
  "monthlyGoals": [
    {
      "month": 1,
      "monthName": "Month name",
      "topics": ["List of topics to complete"],
      "subjectFocus": "Primary subject emphasis",
      "monthlyTarget": "Specific monthly achievement target",
      "majorMilestone": "Key milestone for the month"
    }
  ],
  "complementaryClusters": [
    {
      "clusterName": "Related topic group name",
      "topics": ["Topic 1", "Topic 2", "Topic 3"],
      "learningBenefit": "Why studying these together helps",
      "studySequence": "Optimal order to study them",
      "timeframe": "When to study this cluster"
    }
  ],
  "studyTips": [
    "Specific actionable study tip 1",
    "Specific actionable study tip 2"
  ]
}

Make the schedule realistic, specific, and optimized for a ${studyCapacity.capacity} capacity student with ${studyCapacity.dailyHours} hours daily.`;
  }

  /**
   * Parse Claude's timeline response
   * @param {string} claudeResponse - Raw response from Claude
   * @param {Object} topicSelectionStrategy - Original topic selection
   * @returns {Object} Parsed timeline
   */
  parseTimelineResponse(claudeResponse, topicSelectionStrategy) {
    try {
      // Extract text from Claude API response format
      const responseText = claudeResponse.content?.[0]?.text || claudeResponse.content || claudeResponse.text || claudeResponse;
      
      // Try to extract JSON from Claude's response
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('No JSON found in Claude timeline response');
      }
      
      const parsedTimeline = JSON.parse(jsonMatch[0]);
      
      // Validate and structure the timeline
      return {
        overview: parsedTimeline.overview,
        dailySchedule: parsedTimeline.dailySchedule || [],
        weeklyMilestones: parsedTimeline.weeklyMilestones || [],
        monthlyGoals: parsedTimeline.monthlyGoals || [],
        complementaryClusters: parsedTimeline.complementaryClusters || [],
        studyTips: parsedTimeline.studyTips || [],
        topicSchedule: this.createTopicScheduleFromDaily(parsedTimeline.dailySchedule),
        claudeGenerated: true
      };
    } catch (error) {
      console.error('❌ Failed to parse Claude timeline response:', error.message);
      console.log('Raw Claude timeline response:', claudeResponse.substring(0, 500));
      throw error;
    }
  }

  /**
   * Create topic schedule from daily schedule
   * @param {Array} dailySchedule - Daily schedule from Claude
   * @returns {Array} Topic schedule
   */
  createTopicScheduleFromDaily(dailySchedule) {
    const topicSchedule = [];
    let currentTopic = null;
    let topicStartDate = null;
    
    dailySchedule.forEach((day, index) => {
      if (day.mainTopic !== currentTopic) {
        // New topic started
        if (currentTopic) {
          // Finish previous topic
          topicSchedule.push({
            topic: currentTopic,
            startDate: topicStartDate,
            endDate: dailySchedule[index - 1].date,
            daysRequired: index - topicSchedule.length,
            subject: dailySchedule[index - 1].subject
          });
        }
        currentTopic = day.mainTopic;
        topicStartDate = day.date;
      }
    });
    
    // Add the last topic
    if (currentTopic && dailySchedule.length > 0) {
      topicSchedule.push({
        topic: currentTopic,
        startDate: topicStartDate,
        endDate: dailySchedule[dailySchedule.length - 1].date,
        daysRequired: dailySchedule.length - topicSchedule.length,
        subject: dailySchedule[dailySchedule.length - 1].subject
      });
    }
    
    return topicSchedule;
  }

  /**
   * Create basic timeline when Claude API fails
   * @param {Object} topicSelectionStrategy - Topic selection strategy
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} academicContext - Academic context
   * @returns {Object} Basic timeline
   */
  createBasicTimeline(topicSelectionStrategy, studyCapacity, academicContext) {
    console.log('🔄 Using basic timeline generation due to Claude API failure');
    
    try {
      const { selectedTopics } = topicSelectionStrategy;
      const startDate = new Date();
      let currentDate = new Date(startDate);
      
      // Create basic daily schedule
      const dailySchedule = [];
      let dayCounter = 1;
      
      selectedTopics.forEach((topic, topicIndex) => {
        const daysForTopic = topic.daysRequired || 2;
        
        for (let day = 0; day < daysForTopic; day++) {
          const dayDate = new Date(currentDate);
          
          dailySchedule.push({
            day: dayCounter,
            date: `${(dayDate.getMonth() + 1).toString().padStart(2, '0')}/${dayDate.getDate().toString().padStart(2, '0')}/${dayDate.getFullYear()}`,
            mainTopic: topic.topicName,
            subject: topic.subject,
            subtopics: topic.topics || [topic.topicName],
            timeAllocation: {
              theory: `${Math.round(studyCapacity.dailyHours * 0.6 * 10) / 10} hours`,
              practice: `${Math.round(studyCapacity.dailyHours * 0.25 * 10) / 10} hours`,
              revision: `${Math.round(studyCapacity.dailyHours * 0.15 * 10) / 10} hours`
            },
            objectives: [
              `Understand ${topic.topicName} concepts`,
              `Complete theory reading`,
              `Solve basic problems`
            ],
            resources: ["NCERT Textbook", "Reference Book", "Online Videos"],
            practice: ["Solve 10 problems", "Review examples"],
            assessment: ["Self-test understanding", "Solve practice questions"],
            complementaryLearning: "Review related topics",
            nextDayPrep: "Prepare for next topic"
          });
          
          dayCounter++;
          currentDate.setDate(currentDate.getDate() + 1);
        }
      });
      
      // Create weekly milestones
      const weeklyMilestones = [];
      for (let week = 1; week <= Math.ceil(dailySchedule.length / 7); week++) {
        const weekStart = (week - 1) * 7;
        const weekEnd = Math.min(week * 7, dailySchedule.length);
        const weekTopics = dailySchedule.slice(weekStart, weekEnd).map(day => day.mainTopic);
        const uniqueTopics = [...new Set(weekTopics)];
        
        weeklyMilestones.push({
          week: week,
          startDate: dailySchedule[weekStart]?.date || 'TBD',
          endDate: dailySchedule[weekEnd - 1]?.date || 'TBD',
          topics: uniqueTopics,
          focusArea: week === 1 ? "Foundation building" : "Concept mastery",
          weeklyGoal: `Complete ${uniqueTopics.length} topics with understanding`,
          assessment: "Weekly test on covered topics"
        });
      }
      
      // Create monthly goals
      const monthlyGoals = [{
        month: 1,
        monthName: startDate.toLocaleDateString('en-US', { month: 'long' }),
        topics: selectedTopics.slice(0, 10).map(t => t.topicName),
        subjectFocus: "Balanced coverage",
        monthlyTarget: "Complete foundation topics",
        majorMilestone: "Strong conceptual understanding"
      }];
      
      // Create basic complementary clusters
      const complementaryClusters = [{
        clusterName: "Foundation Topics",
        topics: selectedTopics.slice(0, 5).map(t => t.topicName),
        learningBenefit: "Building strong foundation across subjects",
        studySequence: "Sequential with regular review",
        timeframe: "First month"
      }];
      
      const completionDate = new Date(currentDate);
      completionDate.setDate(completionDate.getDate() - 1);
      
      return {
        overview: {
          totalTopics: selectedTopics.length,
          startDate: startDate.toLocaleDateString('en-US'),
          estimatedCompletionDate: completionDate.toLocaleDateString('en-US'),
          totalDays: dailySchedule.length
        },
        dailySchedule: dailySchedule,
        weeklyMilestones: weeklyMilestones,
        monthlyGoals: monthlyGoals,
        complementaryClusters: complementaryClusters,
        studyTips: [
          "Maintain consistent daily study schedule",
          "Focus on understanding concepts rather than memorization",
          "Regular revision of completed topics",
          "Practice previous year questions"
        ],
        topicSchedule: this.createTopicScheduleFromDaily(dailySchedule),
        claudeGenerated: false
      };
    } catch (error) {
      console.error('❌ Basic timeline generation also failed:', error.message);
      
      // Ultimate fallback with minimal schedule
      return {
        overview: {
          totalTopics: 1,
          startDate: new Date().toLocaleDateString('en-US'),
          estimatedCompletionDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US'),
          totalDays: 7
        },
        dailySchedule: [{
          day: 1,
          date: new Date().toLocaleDateString('en-US'),
          mainTopic: "Basic NEET Preparation",
          subject: "physics",
          subtopics: ["Fundamentals"],
          timeAllocation: {
            theory: "3 hours",
            practice: "1 hour", 
            revision: "0.5 hours"
          },
          objectives: ["Start NEET preparation"],
          resources: ["NCERT Books"],
          practice: ["Basic problems"],
          assessment: ["Self assessment"],
          complementaryLearning: "Review basics",
          nextDayPrep: "Continue preparation"
        }],
        weeklyMilestones: [{
          week: 1,
          startDate: new Date().toLocaleDateString('en-US'),
          endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US'),
          topics: ["Basic NEET Preparation"],
          focusArea: "Getting started",
          weeklyGoal: "Begin preparation",
          assessment: "Initial assessment"
        }],
        monthlyGoals: [{
          month: 1,
          monthName: new Date().toLocaleDateString('en-US', { month: 'long' }),
          topics: ["Basic Topics"],
          subjectFocus: "Foundation",
          monthlyTarget: "Get started",
          majorMilestone: "Begin journey"
        }],
        complementaryClusters: [],
        studyTips: ["Start with basics", "Be consistent"],
        topicSchedule: [],
        claudeGenerated: false
      };
    }
  }

  /**
   * Create daily breakdown for topic study
   * @param {Object} topic - Topic object
   * @param {number} daysRequired - Days required
   * @param {Object} studyCapacity - Study capacity
   * @returns {Array} Daily breakdown
   */
  createDailyTopicBreakdown(topic, daysRequired, studyCapacity) {
    const dailyBreakdown = [];
    const topicsPerDay = topic.topics || ['Main Topic'];
    const subtopicsPerDay = Math.ceil(topicsPerDay.length / daysRequired);
    
    for (let day = 1; day <= daysRequired; day++) {
      const startIndex = (day - 1) * subtopicsPerDay;
      const endIndex = Math.min(day * subtopicsPerDay, topicsPerDay.length);
      const daySubtopics = topicsPerDay.slice(startIndex, endIndex);
      
      dailyBreakdown.push({
        day: day,
        subtopics: daySubtopics,
        studyPlan: {
          theory: this.calculateTheoryTime(daySubtopics, studyCapacity),
          practice: this.calculatePracticeTime(daySubtopics, studyCapacity),
          revision: this.calculateRevisionTime(daySubtopics, studyCapacity)
        },
        objectives: this.createDayObjectives(daySubtopics, topic),
        resources: this.getDayResources(daySubtopics, topic),
        selfAssessment: this.createDayAssessment(daySubtopics, topic)
      });
    }
    
    return dailyBreakdown;
  }

  /**
   * Create complementary topic clusters for parallel learning
   * @param {Array} selectedTopics - Selected topics
   * @param {Object} studyCapacity - Study capacity
   * @returns {Array} Complementary topic clusters
   */
  createComplementaryTopicClusters(selectedTopics, studyCapacity, foundationRecoveryPlan = null) {
    const clusters = [];
    
    // If foundation recovery plan exists, create cross-class correlation clusters first
    if (foundationRecoveryPlan && foundationRecoveryPlan.parallelStudyPairs) {
      foundationRecoveryPlan.parallelStudyPairs.forEach((pair, index) => {
        clusters.push({
          id: `foundation_cluster_${index + 1}`,
          subject: pair.subject,
          type: 'cross_class_correlation',
          mainTopic: { name: pair.class12.name, classLevel: '12' },
          foundationTopic: { name: pair.class11.name, classLevel: '11' },
          complementaryTopics: [],
          learningStrategy: 'Foundation Recovery - Study Class 11 foundation before Class 12 application',
          timeAllocation: { foundationDays: 2, applicationDays: 3 },
          parallelLearningBenefits: 'Strong Class 11 foundation ensures better understanding of Class 12 concepts',
          studySequence: [`Study ${pair.class11.name} (Class 11) first`, `Then apply concepts in ${pair.class12.name} (Class 12)`],
          priority: pair.priority
        });
      });
    }
    
    // Group topics by subject
    const subjectGroups = {
      physics: selectedTopics.filter(t => t.subject === 'physics'),
      chemistry: selectedTopics.filter(t => t.subject === 'chemistry'),
      biology: selectedTopics.filter(t => t.subject === 'biology')
    };
    
    // Create clusters based on conceptual connections
    ['physics', 'chemistry', 'biology'].forEach(subject => {
      const subjectTopics = subjectGroups[subject];
      if (subjectTopics.length === 0) return;
      
      // Find topics that can be studied together
      const conceptualClusters = this.findConceptualClusters(subjectTopics);
      
      conceptualClusters.forEach((cluster, index) => {
        clusters.push({
          id: `${subject}_cluster_${index + 1}`,
          subject: subject,
          type: 'conceptual',
          mainTopic: cluster.primary,
          complementaryTopics: cluster.secondary,
          learningStrategy: this.getClusterLearningStrategy(cluster, studyCapacity),
          timeAllocation: this.getClusterTimeAllocation(cluster, studyCapacity),
          parallelLearningBenefits: this.explainParallelBenefits(cluster),
          studySequence: this.createClusterStudySequence(cluster)
        });
      });
    });
    
    return clusters;
  }

  /**
   * Find conceptual clusters within subject topics
   * @param {Array} subjectTopics - Topics from same subject
   * @returns {Array} Conceptual clusters
   */
  findConceptualClusters(subjectTopics) {
    const clusters = [];
    const usedTopics = new Set();
    
    subjectTopics.forEach(topic => {
      if (usedTopics.has(topic.id)) return;
      
      const cluster = {
        primary: topic,
        secondary: []
      };
      
      // Find complementary topics based on prerequisites and concepts
      topic.complementaryTopics?.forEach(compId => {
        const compTopic = subjectTopics.find(t => t.id === compId && !usedTopics.has(t.id));
        if (compTopic) {
          cluster.secondary.push(compTopic);
          usedTopics.add(compTopic.id);
        }
      });
      
      // Find topics with shared prerequisites
      subjectTopics.forEach(otherTopic => {
        if (otherTopic.id !== topic.id && !usedTopics.has(otherTopic.id)) {
          const sharedPrerequisites = this.findSharedPrerequisites(topic, otherTopic);
          if (sharedPrerequisites.length > 0) {
            cluster.secondary.push(otherTopic);
            usedTopics.add(otherTopic.id);
          }
        }
      });
      
      usedTopics.add(topic.id);
      if (cluster.secondary.length > 0) {
        clusters.push(cluster);
      }
    });
    
    return clusters;
  }

  /**
   * Update study plan response to show detailed topic timeline
   * @param {Object} studyPlan - Study plan
   * @param {Object} academicContext - Academic context
   * @returns {string} Study plan response
   */
  buildStudyPlanResponse(studyPlan, academicContext) {
    const { overview, intelligentTopicSelection, detailedTimeline } = studyPlan;
    const firstWeek = detailedTimeline.weeklySchedule[0];
    const firstMonth = detailedTimeline.monthlyGoals[0];
    
    return `🎯 **Your Personalized NEET Study Plan with Specific Topics & Timeline**

**📊 Plan Overview:**
• **Study Duration:** ${overview.monthsRemaining} months (${overview.totalHours} total hours)
• **Daily Commitment:** ${overview.dailyHours} hours
• **Strategy:** ${intelligentTopicSelection.strategy}
• **Topics Selected:** ${overview.totalTopicsPlanned}/${intelligentTopicSelection.totalAvailableTopics} (optimized for your time)

**🎯 Intelligent Topic Selection:**
• **Critical Topics:** ${intelligentTopicSelection.priorityBreakdown.critical || 0} (must-study)
• **High Priority:** ${intelligentTopicSelection.priorityBreakdown.high || 0} (important for score)
• **Medium Priority:** ${intelligentTopicSelection.priorityBreakdown.medium || 0} (if time permits)

**📚 Student Data Integration:**
• **Your Weak Areas Addressed:** ${intelligentTopicSelection.studentDataIntegration.weakTopicsAddressed}
• **Strong Areas Reinforced:** ${intelligentTopicSelection.studentDataIntegration.strongTopicsReinforced}
• **Balancing Strategy:** ${intelligentTopicSelection.studentDataIntegration.balancingStrategy}

**📅 Week 1 Detailed Schedule (${firstWeek?.startDate}):**
${firstWeek?.topics.map(t => `• **${t.topic}** (${t.subject}) - ${t.priority} priority`).join('\n') || 'Loading detailed schedule...'}

**🎯 Week 1 Goal:** ${firstWeek?.weeklyGoal || 'Establish strong foundation'}

**📈 Month 1 Target (${firstMonth?.monthName}):**
• **Total Topics:** ${firstMonth?.totalTopics || 0} topics
• **Subject Focus:** ${this.formatSubjectDistribution(firstMonth?.subjectDistribution)}
• **Monthly Goal:** ${firstMonth?.monthlyTarget || 'Build foundation'}

**⏰ Next 7 Days - Specific Topics to Study:**
${this.getNext7DaysTopics(detailedTimeline)}

**🔄 Complementary Learning:**
${studyPlan.complementaryTopicClusters.slice(0, 2).map(cluster => 
  `• Study **${cluster.mainTopic.name}** alongside **${cluster.complementaryTopics[0]?.name || 'related topics'}** for better understanding`
).join('\n')}

**💡 Why This Plan Works:**
• Topics selected based on NEET weightage + your current knowledge
• Parallel learning of related concepts for better retention
• Realistic timeline accounting for your ${overview.dailyHours} hours/day
• Focuses on your weak areas while reinforcing strengths

**🚀 Starting Today:** Begin with **${detailedTimeline.topicSchedule[0]?.topic || 'your first selected topic'}** from **${detailedTimeline.topicSchedule[0]?.subject || 'the syllabus'}**

Ready to start your NEET journey with this personalized roadmap? 🎯`;
  }

  /**
   * Get next 7 days specific topics
   * @param {Object} detailedTimeline - Detailed timeline
   * @returns {string} Next 7 days topics
   */
  getNext7DaysTopics(detailedTimeline) {
    const next7Days = detailedTimeline.topicSchedule.slice(0, 7);
    return next7Days.map((topic, index) => 
      `**Day ${index + 1}:** ${topic.topic} (${topic.subject}) - ${topic.daysRequired} day${topic.daysRequired > 1 ? 's' : ''}`
    ).join('\n') || 'Detailed daily schedule being prepared...';
  }

  /**
   * Format subject distribution
   * @param {Object} distribution - Subject distribution
   * @returns {string} Formatted distribution
   */
  formatSubjectDistribution(distribution) {
    if (!distribution) return 'Balanced across all subjects';
    
    return Object.entries(distribution)
      .map(([subject, count]) => `${subject}: ${count}`)
      .join(', ');
  }

  // Helper methods for topic selection and timeline generation
  
  determineSelectionStrategy(studyCapacity, academicContext) {
    if (studyCapacity.capacity === 'challenging') {
      return 'Strategic High-Yield Focus';
    } else if (studyCapacity.capacity === 'moderate') {
      return 'Balanced Priority-Based Selection';
    } else if (studyCapacity.capacity === 'good') {
      return 'Comprehensive Coverage with Priorities';
    } else {
      return 'Complete Syllabus with Deep Understanding';
    }
  }

  categorizeSelectedTopics(selectedTopics) {
    return selectedTopics.reduce((acc, topic) => {
      const category = topic.selectionCategory.toLowerCase().replace(' ', '');
      acc[category] = (acc[category] || 0) + 1;
      return acc;
    }, {});
  }

  countWeakTopicsAddressed(selectedTopics, studentWeakTopics) {
    return selectedTopics.filter(topic =>
      studentWeakTopics.some(weak => weak.toLowerCase().includes(topic.name.toLowerCase()))
    ).length;
  }

  countStrongTopicsReinforced(selectedTopics, studentStrongTopics) {
    return selectedTopics.filter(topic =>
      studentStrongTopics.some(strong => strong.toLowerCase().includes(topic.name.toLowerCase()))
    ).length;
  }

  explainTopicBalancing(selectedTopics, studentWeakTopics, studentStrongTopics) {
    const weakCount = this.countWeakTopicsAddressed(selectedTopics, studentWeakTopics);
    const strongCount = this.countStrongTopicsReinforced(selectedTopics, studentStrongTopics);
    
    if (weakCount > strongCount * 2) {
      return 'Heavily focused on improving weak areas';
    } else if (strongCount > weakCount) {
      return 'Building on existing strengths while addressing gaps';
    } else {
      return 'Balanced approach addressing both weak and strong areas';
    }
  }

  calculateTopicCompletionDays(topic, studyCapacity) {
    const baseTime = studyCapacity.syllabusCompletionEstimate.timeAllocation.newTopics;
    const difficulty = topic.difficulty || 'Medium';
    
    const multipliers = {
      'Easy': 0.8,
      'Medium': 1.0,
      'Hard': 1.3
    };
    
    return Math.ceil((baseTime * multipliers[difficulty]) / studyCapacity.dailyHours * 24);
  }

  findComplementaryTopics(topic, allTopics) {
    return allTopics
      .filter(t => t.id !== topic.id && (
        t.subject === topic.subject ||
        this.findSharedPrerequisites(topic, t).length > 0
      ))
      .slice(0, 3)
      .map(t => t.id);
  }

  findSharedPrerequisites(topic1, topic2) {
    const prereq1 = topic1.prerequisites || [];
    const prereq2 = topic2.prerequisites || [];
    return prereq1.filter(p => prereq2.includes(p));
  }

  determineStudyPhase(index, totalTopics, monthsRemaining) {
    const phase = Math.floor((index / totalTopics) * Math.min(monthsRemaining, 4));
    const phases = ['Foundation', 'Building', 'Advanced', 'Mastery'];
    return phases[phase] || 'Advanced';
  }

  getFallbackChapters() {
    // Fallback high-priority NEET topics
    return [
      { id: 'PHY_MECHANICS', name: 'Mechanics', subject: 'physics', weightage: 6, difficulty: 'Medium' },
      { id: 'CHE_ORGANIC', name: 'Organic Chemistry', subject: 'chemistry', weightage: 7, difficulty: 'Hard' },
      { id: 'BIO_GENETICS', name: 'Genetics', subject: 'biology', weightage: 5, difficulty: 'Medium' }
    ];
  }

  // Additional helper methods would be implemented for:
  // - createDayObjectives, getDayResources, createDayAssessment
  // - getClusterLearningStrategy, getClusterTimeAllocation, explainParallelBenefits
  // - calculateTheoryTime, calculatePracticeTime, calculateRevisionTime
  // - createTopicMilestones, getTopicResources, createTopicAssessmentPlan
  // - generateWeeklyGoal, generateMonthlyTarget, createMonthlyAssessmentPlan

  /**
   * Create phase-wise study plan
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} syllabusAnalysis - Syllabus analysis
   * @param {Object} academicContext - Academic context
   * @returns {Object} Phase-wise plan
   */
  createPhaseWisePlan(studyCapacity, syllabusAnalysis, academicContext) {
    const monthsRemaining = academicContext.neetExamMonthsRemaining.months;
    
    if (monthsRemaining >= 12) {
      return {
        phase1: { months: '1-4', focus: 'Foundation Building', description: 'Complete Class 11 concepts, basic problem solving' },
        phase2: { months: '5-8', focus: 'Advanced Learning', description: 'Class 12 concepts, intermediate problems' },
        phase3: { months: '9-11', focus: 'Practice & Tests', description: 'Mock tests, previous years, weak area focus' },
        phase4: { months: '12', focus: 'Final Revision', description: 'Quick revision, stress management, exam strategy' }
      };
    } else if (monthsRemaining >= 6) {
      return {
        phase1: { months: '1-2', focus: 'Rapid Coverage', description: 'High-weightage topics, concept building' },
        phase2: { months: '3-4', focus: 'Practice Intensive', description: 'Problem solving, mock tests, speed building' },
        phase3: { months: '5-6', focus: 'Revision & Polish', description: 'Final revision, exam strategy, confidence building' }
      };
    } else {
      return {
        phase1: { months: '1-2', focus: 'Strategic Topics', description: 'Only high-weightage, previously asked topics' },
        phase2: { months: '3+', focus: 'Practice & Perfect', description: 'Daily tests, time management, accuracy improvement' }
      };
    }
  }

  /**
   * Create daily schedule
   * @param {number} dailyHours - Daily hours
   * @param {Object} subjectDistribution - Subject distribution
   * @returns {Object} Daily schedule
   */
  createDailySchedule(dailyHours, subjectDistribution) {
    return {
      morning: {
        time: '6:00 - 9:00 AM',
        subjects: ['Physics'],
        hours: subjectDistribution.physics,
        focus: 'Problem solving (mind is fresh)'
      },
      afternoon: {
        time: '2:00 - 5:00 PM',
        subjects: ['Chemistry'],
        hours: subjectDistribution.chemistry,
        focus: 'Theory + numerical practice'
      },
      evening: {
        time: '7:00 - 10:00 PM',
        subjects: ['Biology'],
        hours: subjectDistribution.biology,
        focus: 'Reading, diagrams, memorization'
      },
      breaks: {
        description: 'Take 15-min breaks every hour, 30-min lunch break',
        totalBreakTime: Math.floor(dailyHours * 0.2)
      }
    };
  }

  /**
   * Create weekly schedule
   * @param {number} dailyHours - Daily hours
   * @returns {Object} Weekly schedule
   */
  createWeeklySchedule(dailyHours) {
    return {
      monday: { focus: 'Physics + Chemistry', hours: dailyHours },
      tuesday: { focus: 'Biology + Physics', hours: dailyHours },
      wednesday: { focus: 'Chemistry + Biology', hours: dailyHours },
      thursday: { focus: 'Physics + Chemistry', hours: dailyHours },
      friday: { focus: 'Biology + Revision', hours: dailyHours },
      saturday: { focus: 'Mock Test + Analysis', hours: Math.min(dailyHours + 2, 8) },
      sunday: { focus: 'Revision + Rest', hours: Math.floor(dailyHours * 0.7) }
    };
  }

  /**
   * Create monthly milestones
   * @param {number} monthsRemaining - Months remaining
   * @param {Object} syllabusAnalysis - Syllabus analysis
   * @returns {Array} Monthly milestones
   */
  createMonthlyMilestones(monthsRemaining, syllabusAnalysis) {
    const milestones = [];
    const topicsPerMonth = Math.ceil(syllabusAnalysis.unexploredTopics / Math.max(monthsRemaining - 1, 1));
    
    for (let i = 1; i <= monthsRemaining; i++) {
      if (i === monthsRemaining) {
        milestones.push({
          month: i,
          title: 'Final Sprint',
          targets: ['Complete final revision', 'Daily practice tests', 'Stress management'],
          topicsTarget: 0
        });
      } else if (i >= monthsRemaining - 1) {
        milestones.push({
          month: i,
          title: 'Pre-Exam Preparation',
          targets: ['Complete weak topics', 'Speed improvement', 'Mock test analysis'],
          topicsTarget: topicsPerMonth
        });
      } else {
        milestones.push({
          month: i,
          title: `Foundation Month ${i}`,
          targets: [`Complete ${topicsPerMonth} new topics`, 'Regular practice', 'Weekly assessments'],
          topicsTarget: topicsPerMonth
        });
      }
    }
    
    return milestones;
  }

  /**
   * Create study strategy
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} syllabusAnalysis - Syllabus analysis
   * @returns {Object} Study strategy
   */
  createStudyStrategy(studyCapacity, syllabusAnalysis) {
    return {
      approach: studyCapacity.capacity === 'excellent' ? 'comprehensive' : 'strategic',
      focusOrder: ['High-weightage topics', 'Frequently asked topics', 'Easy scoring topics'],
      studyMethod: [
        '📖 **Read** concept from NCERT',
        '📝 **Write** key points and formulas',
        '🧠 **Understand** with examples',
        '💡 **Practice** basic problems',
        '🎯 **Test** understanding with questions',
        '🔄 **Revise** regularly'
      ],
      timeAllocation: {
        newTopics: '60%',
        practice: '25%',
        revision: '15%'
      }
    };
  }

  /**
   * Create practice schedule
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} academicContext - Academic context
   * @returns {Object} Practice schedule
   */
  createPracticeSchedule(studyCapacity, academicContext) {
    const monthsRemaining = academicContext.neetExamMonthsRemaining.months;
    
    return {
      daily: 'Solve 10-15 questions from studied topics',
      weekly: monthsRemaining > 6 ? 'One subject-wise test' : 'Two full-length tests',
      monthly: 'Full NEET mock test + detailed analysis',
      progression: {
        month1: 'Topic-wise questions',
        month2: 'Chapter-wise tests',
        month3: 'Subject-wise tests',
        month4: 'Full-length mocks'
      }
    };
  }

  /**
   * Create revision plan
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} academicContext - Academic context
   * @returns {Object} Revision plan
   */
  createRevisionPlan(studyCapacity, academicContext) {
    return {
      frequency: {
        immediate: 'Same day evening',
        weekly: 'Weekend comprehensive review',
        monthly: 'Full month topics revision'
      },
      method: [
        'Quick formula and concept recap',
        'Solve representative problems',
        'Identify and note weak areas',
        'Create short notes for quick review'
      ],
      finalRevision: {
        duration: 'Last 15 days before NEET',
        focus: 'Only high-yield topics and formulas',
        strategy: 'Quick reading + practice tests'
      }
    };
  }

  /**
   * Create motivational support plan
   * @param {Object} motivationalContext - Motivational context
   * @param {Object} academicContext - Academic context
   * @returns {Object} Motivational support
   */
  createMotivationalSupport(motivationalContext, academicContext) {
    return {
      dailyAffirmations: [
        'I am making progress every single day',
        'Every topic I master brings me closer to my medical seat',
        'I have enough time and ability to succeed in NEET'
      ],
      weeklyGoals: 'Set and achieve small, measurable targets',
      progressTracking: 'Maintain a study log and celebrate small wins',
      stressManagement: [
        'Take regular breaks',
        'Maintain healthy sleep schedule',
        'Exercise 30 minutes daily',
        'Practice relaxation techniques'
      ],
      supportSystem: 'Stay connected with family, friends, and mentors'
    };
  }

  /**
   * Build study plan response
   * @param {Object} studyPlan - Study plan
   * @param {Object} academicContext - Academic context
   * @returns {string} Study plan response
   */
  buildStudyPlanResponse(studyPlan, academicContext) {
    const { overview, dailySchedule, monthlyMilestones, priorityTopics } = studyPlan;
    
    return `🎯 **Your Personalized NEET Study Plan is Ready!**

**📊 Plan Overview:**
• **Study Duration:** ${overview.monthsRemaining} months (${overview.totalHours} total hours)
• **Daily Commitment:** ${overview.dailyHours} hours
• **Capacity Level:** ${overview.capacityLevel}

**📅 Your Daily Schedule:**
🌅 **Morning (${dailySchedule.morning.time}):** Physics - ${dailySchedule.morning.hours} hours
     Focus: ${dailySchedule.morning.focus}

🌤️ **Afternoon (${dailySchedule.afternoon.time}):** Chemistry - ${dailySchedule.afternoon.hours} hours
     Focus: ${dailySchedule.afternoon.focus}

🌆 **Evening (${dailySchedule.evening.time}):** Biology - ${dailySchedule.evening.hours} hours
     Focus: ${dailySchedule.evening.focus}

**🎯 Priority Topics to Master First:**
${priorityTopics.slice(0, 10).map((topic, index) => `${index + 1}. ${topic}`).join('\n')}

**📈 Month 1 Milestone:**
${monthlyMilestones[0].targets.map(target => `• ${target}`).join('\n')}

**💪 Key Success Strategies:**
• Start with high-weightage topics for quick score gains
• Maintain consistency over intensity
• Regular practice and revision
• Weekly progress tracking
• Stay positive and motivated!

Remember: **You have everything you need to succeed!** This plan is designed specifically for your situation, time availability, and current preparation level. Follow it consistently, and you'll see remarkable progress.

**Your NEET journey starts NOW!** 🚀

Would you like me to break down any specific part of this plan or help you get started with your first study session?`;
  }

  /**
   * Create conversation state for a student
   * @param {string} studentId - Student ID
   * @param {string} initialPhase - Initial phase
   * @returns {Object} Conversation state
   */
  createConversationState(studentId, initialPhase = 'discovery') {
    const conversationState = {
      studentId,
      currentPhase: initialPhase,
      startTime: new Date().toISOString(),
      lastActivity: new Date().toISOString(),
      questionsAsked: 0,
      responses: [],
      aiResponses: [],
      assessmentQuestions: [],
      currentQuestionIndex: 0,
      
      addResponse: function(response) {
        this.responses.push({
          timestamp: new Date().toISOString(),
          response: response,
          phase: this.currentPhase
        });
        this.questionsAsked++;
        this.lastActivity = new Date().toISOString();
      },
      
      addAIResponse: function(response) {
        this.aiResponses.push({
          timestamp: new Date().toISOString(),
          response: response,
          phase: this.currentPhase
        });
      },
      
      moveToPhase: function(newPhase) {
        this.currentPhase = newPhase;
        this.lastActivity = new Date().toISOString();
      },
      
      getLastResponse: function() {
        return this.responses.length > 0 ? this.responses[this.responses.length - 1].response : '';
      },
      
      getContextForLLM: function() {
        return {
          currentPhase: this.currentPhase,
          questionsAsked: this.questionsAsked,
          responses: this.responses,
          studentInfo: this.studentData || {}
        };
      },
      
      getComprehensiveData: function() {
        return {
          studentId: this.studentId,
          responses: this.responses,
          classLevel: this.extractClassLevel(),
          studyHours: this.extractStudyHours(),
          subjectPreferences: this.extractSubjectPreferences(),
          challenges: this.extractChallenges(),
          timeToNEET: this.extractTimeToNEET()
        };
      },
      
      extractClassLevel: function() {
        const classResponse = this.responses.find(r => 
          r.response.toLowerCase().includes('11') || r.response.toLowerCase().includes('12')
        );
        return classResponse ? (classResponse.response.includes('11') ? '11' : '12') : 'unknown';
      },
      
      extractStudyHours: function() {
        const studyResponse = this.responses.find(r => 
          r.response.match(/\d+/) && r.response.toLowerCase().includes('hour')
        );
        return studyResponse ? parseInt(studyResponse.response.match(/\d+/)[0]) : 0;
      },
      
      extractSubjectPreferences: function() {
        const subjects = ['physics', 'chemistry', 'biology'];
        const preferences = {};
        
        this.responses.forEach(r => {
          subjects.forEach(subject => {
            if (r.response.toLowerCase().includes(subject)) {
              preferences[subject] = (preferences[subject] || 0) + 1;
            }
          });
        });
        
        return preferences;
      },
      
      extractChallenges: function() {
        const challengeKeywords = ['difficult', 'hard', 'challenging', 'problem', 'struggle'];
        const challenges = [];
        
        this.responses.forEach(r => {
          challengeKeywords.forEach(keyword => {
            if (r.response.toLowerCase().includes(keyword)) {
              challenges.push(r.response);
            }
          });
        });
        
        return challenges;
      },
      
      extractTimeToNEET: function() {
        // Calculate based on current date and NEET exam date
        const now = new Date();
        const currentYear = now.getFullYear();
        let neetDate = new Date(currentYear, 4, 5); // May 5th
        
        if (now > neetDate) {
          neetDate = new Date(currentYear + 1, 4, 5);
        }
        
        const timeDiff = neetDate.getTime() - now.getTime();
        const monthsRemaining = Math.floor(timeDiff / (1000 * 3600 * 24 * 30));
        
        return monthsRemaining;
      },
      
      getPublicState: function() {
        return {
          phase: this.currentPhase,
          questionsAsked: this.questionsAsked,
          startTime: this.startTime,
          lastActivity: this.lastActivity
        };
      }
    };
    
    this.conversationStates.set(studentId, conversationState);
    return conversationState;
  }

  /**
   * Get conversation state for a student
   * @param {string} studentId - Student ID
   * @returns {Object|null} Conversation state
   */
  getConversationState(studentId) {
    const state = this.conversationStates.get(studentId);
    
    if (state) {
      // Check if session is expired
      const lastActivity = new Date(state.lastActivity);
      const now = new Date();
      
      if (now - lastActivity > this.sessionTimeout) {
        this.conversationStates.delete(studentId);
        return null;
      }
    }
    
    return state;
  }

  /**
   * Generate initial conversation response using Claude API
   * @param {Object} academicContext - Academic context
   * @param {Object} initialContext - Initial context
   * @returns {Promise<Object>} Initial response
   */
  async generateInitialConversationResponse(academicContext, initialContext) {
    try {
      // Try Claude API for intelligent, personalized discovery
      const intelligentResponse = await this.generateDiscoveryWithClaude(academicContext, initialContext);
      return intelligentResponse;
    } catch (error) {
      console.warn('⚠️ Claude API failed for discovery, using fallback:', error.message);
      // Fallback to enhanced hardcoded response
      return this.generateDiscoveryFallback(academicContext, initialContext);
    }
  }

  /**
   * Generate intelligent discovery conversation using Claude API
   * @param {Object} academicContext - Academic context
   * @param {Object} initialContext - Initial context  
   * @returns {Promise<Object>} Claude-generated discovery response
   */
  async generateDiscoveryWithClaude(academicContext, initialContext) {
    const discoveryPrompt = this.buildDiscoveryPrompt(academicContext, initialContext);
    
    const claudeResponse = await this.llmService.callClaudeAPI(discoveryPrompt, {
      temperature: 0.7, // Higher temperature for natural conversation
      max_tokens: 300   // Keep response concise
    });

    return this.parseDiscoveryResponse(claudeResponse, academicContext);
  }

  /**
   * Build discovery prompt for Claude API
   * @param {Object} academicContext - Academic context
   * @param {Object} initialContext - Initial context
   * @returns {string} Formatted prompt for Claude
   */
  buildDiscoveryPrompt(academicContext, initialContext) {
    const { currentMonthName, neetExamMonthsRemaining, currentTeachingPhase, examPressure } = academicContext;
    
    // Get relevant academic insights from knowledge base
    const currentPhaseInsights = this.getCurrentPhaseInsights(currentTeachingPhase);
    const timeInsights = this.getTimeRemainingInsights(neetExamMonthsRemaining.months);
    
    return `You are an expert NEET AI Coach with deep understanding of Indian medical entrance exam preparation. You're starting your first conversation with a student seeking guidance.

## CURRENT ACADEMIC CONTEXT:
- **Current Month**: ${currentMonthName}
- **Time Remaining**: ${neetExamMonthsRemaining.months} months until NEET
- **Academic Phase**: ${currentTeachingPhase}
- **Exam Pressure Level**: ${examPressure.level}
- **Typical Student Concerns This Phase**: ${currentPhaseInsights}
- **Time Management Focus**: ${timeInsights}

## STUDENT CONTEXT:
${initialContext.userId ? '- This student has an existing account (returning student)' : '- This appears to be a new student'}
${initialContext.referralSource ? `- Referred from: ${initialContext.referralSource}` : ''}

## YOUR TASK:
Create a warm, encouraging first message that:
1. **Greets the student** with appropriate energy level for their likely emotional state
2. **Provides relevant context** about their current timeline and opportunities
3. **Asks ONE strategic question** to understand their situation
4. **Shows empathy** for the academic pressure they might be feeling
5. **Builds confidence** by highlighting what's still achievable in their timeframe

## GUIDELINES:
- Keep tone encouraging but realistic about the timeline
- Ask about their current class (11th/12th) as the primary question
- Reference the academic phase appropriately (${currentTeachingPhase})
- Address any time pressure concerns proactively
- Make them feel supported, not judged
- Limit response to 2-3 sentences + 1 clear question

## RESPONSE FORMAT:
Provide a JSON response with this structure:
{
  "message": "Your encouraging greeting and context",
  "question": "Your strategic follow-up question",
  "tone": "encouraging/supportive/motivational"
}

Generate a personalized discovery conversation starter that makes this student feel confident and supported in their NEET journey.`;
  }

  /**
   * Parse Claude's discovery response
   * @param {string} claudeResponse - Raw response from Claude
   * @param {Object} academicContext - Academic context for fallback
   * @returns {Object} Parsed discovery response
   */
  parseDiscoveryResponse(claudeResponse, academicContext) {
    try {
      // Extract text from Claude API response format
      const responseText = claudeResponse.content?.[0]?.text || claudeResponse.content || claudeResponse.text || claudeResponse;
      
      // Try to parse JSON response
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsedResponse = JSON.parse(jsonMatch[0]);
        
        // Validate required fields
        if (parsedResponse.message && parsedResponse.question) {
          return {
            message: parsedResponse.message,
            question: parsedResponse.question,
            tone: parsedResponse.tone || 'supportive',
            source: 'claude_api'
          };
        }
      }
      
      // If JSON parsing fails, extract message and question from text
      const lines = responseText.split('\n').filter(line => line.trim());
      const message = lines[0] || 'Hello! I\'m your AI Coach here to help with your NEET preparation.';
      const question = lines.find(line => line.includes('?')) || 'Which class are you currently in - 11th or 12th?';
      
      return {
        message: message,
        question: question,
        tone: 'supportive',
        source: 'claude_api_parsed'
      };
      
    } catch (error) {
      console.error('❌ Failed to parse Claude discovery response:', error.message);
      throw new Error(`Discovery response parsing failed: ${error.message}`);
    }
  }

  /**
   * Generate fallback discovery response (enhanced hardcoded)
   * @param {Object} academicContext - Academic context
   * @param {Object} initialContext - Initial context
   * @returns {Object} Fallback discovery response
   */
  generateDiscoveryFallback(academicContext, initialContext) {
    const { currentMonthName, neetExamMonthsRemaining, currentTeachingPhase } = academicContext;
    
    // Enhanced fallback with more contextual awareness
    let greeting = `Hello! I'm your AI Coach here to help you with your NEET preparation. `;
    
    // Context-aware messaging based on time remaining
    if (neetExamMonthsRemaining.months >= 10) {
      greeting += `Great timing - with ${neetExamMonthsRemaining.months} months ahead, you have excellent opportunity to build a strong foundation. `;
    } else if (neetExamMonthsRemaining.months >= 6) {
      greeting += `With ${neetExamMonthsRemaining.months} months remaining, this is a crucial phase for focused preparation. `;
    } else {
      greeting += `Time is precious with ${neetExamMonthsRemaining.months} months left, but strategic preparation can still yield great results. `;
    }
    
    const phase = `We're in the ${currentTeachingPhase.toLowerCase()} phase, which is perfect for ${this.getPhaseActivity(currentTeachingPhase)}. `;
    const question = `Let's start by understanding your current situation - which class are you in, 11th or 12th?`;
    
    return {
      message: greeting + phase,
      question: question,
      tone: 'supportive',
      source: 'fallback_enhanced'
    };
  }

  /**
   * Get current phase insights
   * @param {string} phase - Current teaching phase
   * @returns {string} Phase-specific insights
   */
  getCurrentPhaseInsights(phase) {
    const phaseInsights = {
      'Foundation Building - Core Concepts': 'building strong conceptual understanding, starting NCERT mastery',
      'Intensive Preparation - Advanced Topics': 'tackling advanced problems, intensive practice, mock tests',
      'Revision & Fine-tuning': 'revision strategies, exam techniques, final preparation anxiety',
      'Final Sprint': 'last-minute revision, exam anxiety management, strategic topic selection'
    };
    
    return phaseInsights[phase] || 'focused preparation and strategic planning';
  }

  /**
   * Get time remaining insights
   * @param {number} monthsRemaining - Months until NEET
   * @returns {string} Time-specific insights
   */
  getTimeRemainingInsights(monthsRemaining) {
    if (monthsRemaining >= 10) return 'ample time for comprehensive preparation';
    if (monthsRemaining >= 6) return 'focused preparation with strategic topic selection';
    if (monthsRemaining >= 3) return 'intensive revision and high-yield topic focus';
    return 'strategic last-minute preparation and exam readiness';
  }

  /**
   * Get phase-specific activity description
   * @param {string} phase - Current teaching phase
   * @returns {string} Activity description
   */
  getPhaseActivity(phase) {
    const activities = {
      'Foundation Building - Core Concepts': 'establishing strong fundamentals',
      'Intensive Preparation - Advanced Topics': 'intensive practice and problem-solving',
      'Revision & Fine-tuning': 'comprehensive revision and mock tests',
      'Final Sprint': 'final preparation and exam strategies'
    };
    
    return activities[phase] || 'strategic preparation';
  }

  /**
   * Check if we have enough information for assessment
   * @param {Object} conversationState - Conversation state
   * @returns {boolean} Whether we have enough info
   */
  hasEnoughInfoForAssessment(conversationState) {
    const data = conversationState.getComprehensiveData();
    return data.classLevel !== 'unknown' && data.studyHours > 0;
  }

  /**
   * Determine assessment focus based on conversation
   * @param {Object} conversationState - Conversation state
   * @param {Object} academicContext - Academic context
   * @returns {Object} Assessment focus
   */
  determineAssessmentFocus(conversationState, academicContext) {
    const data = conversationState.getComprehensiveData();
    
    return {
      classLevel: data.classLevel,
      timeToNEET: data.timeToNEET,
      studyHours: data.studyHours,
      focusSubjects: Object.keys(data.subjectPreferences).slice(0, 2),
      assessmentType: 'conceptual',
      difficulty: data.classLevel === '12' ? 'medium' : 'easy'
    };
  }

  /**
   * Generate assessment questions
   * @param {Object} assessmentFocus - Assessment focus
   * @param {Object} academicContext - Academic context
   * @returns {Promise<Array>} Assessment questions
   */
  async generateAssessmentQuestions(assessmentFocus, academicContext) {
    try {
      const questions = await this.llmService.generateAssessmentQuestions(assessmentFocus, assessmentFocus.focusSubjects);
      return questions.length > 0 ? questions : this.getFallbackAssessmentQuestions(assessmentFocus);
    } catch (error) {
      console.error('❌ Failed to generate assessment questions:', error.message);
      return this.getFallbackAssessmentQuestions(assessmentFocus);
    }
  }

  /**
   * Get fallback assessment questions
   * @param {Object} assessmentFocus - Assessment focus
   * @returns {Array} Fallback questions
   */
  getFallbackAssessmentQuestions(assessmentFocus) {
    return [
      'How comfortable are you with solving numerical problems in Physics?',
      'What is your biggest challenge in Chemistry - organic, inorganic, or physical?',
      'How do you approach Biology - do you prefer memorization or understanding concepts?'
    ];
  }

  /**
   * Generate recommendations based on analysis
   * @param {Object} analysis - AI analysis
   * @param {Object} academicContext - Academic context
   * @returns {Object} Recommendations
   */
  generateRecommendations(analysis, academicContext) {
    return {
      studySchedule: this.generateStudySchedule(analysis, academicContext),
      priorityTopics: this.generatePriorityTopics(analysis, academicContext),
      practiceStrategy: this.generatePracticeStrategy(analysis, academicContext),
      timeManagement: this.generateTimeManagement(analysis, academicContext)
    };
  }

  /**
   * Generate study schedule recommendations
   * @param {Object} analysis - AI analysis
   * @param {Object} academicContext - Academic context
   * @returns {Object} Study schedule
   */
  generateStudySchedule(analysis, academicContext) {
    const { examPressure } = academicContext;
    const recommendedHours = this.knowledgeBase.getRecommendedStudyHours(examPressure.level);
    
    return {
      dailyHours: recommendedHours.daily,
      subjectDistribution: {
        physics: recommendedHours.physics,
        chemistry: recommendedHours.chemistry,
        biology: recommendedHours.biology
      },
      weeklyPattern: this.generateWeeklyPattern(recommendedHours)
    };
  }

  /**
   * Generate priority topics based on analysis
   * @param {Object} analysis - AI analysis
   * @param {Object} academicContext - Academic context
   * @returns {Array} Priority topics
   */
  generatePriorityTopics(analysis, academicContext) {
    const highWeightageTopics = [
      this.knowledgeBase.getHighWeightageTopics('physics'),
      this.knowledgeBase.getHighWeightageTopics('chemistry'),
      this.knowledgeBase.getHighWeightageTopics('biology')
    ].flat();
    
    return highWeightageTopics.slice(0, 10);
  }

  /**
   * Generate practice strategy
   * @param {Object} analysis - AI analysis
   * @param {Object} academicContext - Academic context
   * @returns {Object} Practice strategy
   */
  generatePracticeStrategy(analysis, academicContext) {
    const { examPressure } = academicContext;
    const strategy = this.knowledgeBase.getPriorityStrategy(examPressure.level);
    
    return {
      approach: strategy.approach,
      focus: strategy.focus,
      practiceTests: strategy.practiceTests,
      revision: strategy.revision
    };
  }

  /**
   * Generate time management recommendations
   * @param {Object} analysis - AI analysis
   * @param {Object} academicContext - Academic context
   * @returns {Object} Time management
   */
  generateTimeManagement(analysis, academicContext) {
    const { neetExamMonthsRemaining } = academicContext;
    
    return {
      timeRemaining: neetExamMonthsRemaining,
      milestones: this.generateMilestones(neetExamMonthsRemaining),
      urgentActions: this.generateUrgentActions(analysis, academicContext)
    };
  }

  /**
   * Generate weekly study pattern
   * @param {Object} recommendedHours - Recommended hours
   * @returns {Object} Weekly pattern
   */
  generateWeeklyPattern(recommendedHours) {
    return {
      monday: { physics: 2, chemistry: 2, biology: 2 },
      tuesday: { physics: 2, chemistry: 2, biology: 2 },
      wednesday: { physics: 2, chemistry: 2, biology: 2 },
      thursday: { physics: 2, chemistry: 2, biology: 2 },
      friday: { physics: 2, chemistry: 2, biology: 2 },
      saturday: { revision: 4, practice: 2 },
      sunday: { practice: 4, rest: 2 }
    };
  }

  /**
   * Generate study milestones
   * @param {Object} timeRemaining - Time remaining
   * @returns {Array} Milestones
   */
  generateMilestones(timeRemaining) {
    const milestones = [];
    const months = timeRemaining.months;
    
    if (months > 6) {
      milestones.push('Complete Class 11 syllabus revision');
      milestones.push('Start Class 12 advanced topics');
    } else if (months > 3) {
      milestones.push('Complete all syllabus coverage');
      milestones.push('Begin intensive practice tests');
    } else {
      milestones.push('Focus on high-weightage topics only');
      milestones.push('Daily practice tests and revision');
    }
    
    return milestones;
  }

  /**
   * Generate urgent actions
   * @param {Object} analysis - AI analysis
   * @param {Object} academicContext - Academic context
   * @returns {Array} Urgent actions
   */
  generateUrgentActions(analysis, academicContext) {
    const actions = [];
    const { examPressure } = academicContext;
    
    if (examPressure.level === 'critical') {
      actions.push('Take daily practice tests');
      actions.push('Focus only on high-weightage topics');
      actions.push('Solve previous year questions');
    } else if (examPressure.level === 'high') {
      actions.push('Increase study hours');
      actions.push('Focus on weak areas');
      actions.push('Regular mock tests');
    }
    
    return actions;
  }

  /**
   * Format analysis response for display
   * @param {Object} analysis - AI analysis
   * @param {Object} academicContext - Academic context
   * @returns {string} Formatted response
   */
  formatAnalysisResponse(analysis, academicContext) {
    return `Based on our conversation, here's my assessment of your NEET preparation:

**Preparation Level:** ${analysis.strengthLevel}

**Your Strengths:**
${analysis.keyStrengths.map(strength => `• ${strength}`).join('\n')}

**Areas for Improvement:**
${analysis.majorGaps.map(gap => `• ${gap}`).join('\n')}

**Recommended Focus:** ${analysis.recommendedFocus}

Given that you have ${academicContext.neetExamMonthsRemaining.months} months until NEET, I'll now provide you with a personalized study plan.`;
  }

  /**
   * Format existing student response
   * @param {Object} analysis - AI analysis
   * @param {Object} academicContext - Academic context
   * @returns {string} Formatted response
   */
  formatExistingStudentResponse(analysis, academicContext) {
    return `Welcome back! I've analyzed your performance data and here's what I found:

**Current Performance Level:** ${analysis.strengthLevel}

**Your Strong Areas:**
${analysis.keyStrengths.map(strength => `• ${strength}`).join('\n')}

**Areas Needing Attention:**
${analysis.majorGaps.map(gap => `• ${gap}`).join('\n')}

With ${academicContext.neetExamMonthsRemaining.months} months remaining for NEET, let me create a targeted improvement plan for you.`;
  }

  /**
   * Format guidance response
   * @param {Object} guidance - Guidance object
   * @param {Object} academicContext - Academic context
   * @returns {string} Formatted guidance
   */
  formatGuidanceResponse(guidance, academicContext) {
    return `Here's your personalized NEET preparation plan:

**Priority Focus:** ${guidance.priorityFocus}

**Daily Study Schedule:** ${guidance.dailySchedule}

**Weekly Goals:** ${guidance.weeklyGoals}

**Recommended Resources:** ${guidance.resources}

Remember, consistency is key! With ${academicContext.neetExamMonthsRemaining.months} months to go, following this plan will help you maximize your NEET score.

Good luck with your preparation! 🎯`;
  }

  /**
   * Get error response
   * @param {string} message - Error message
   * @returns {Object} Error response
   */
  getErrorResponse(message) {
    return {
      success: false,
      type: 'error',
      message: `I apologize, but I encountered an issue: ${message}. Let's try starting fresh - which class are you currently in?`,
      error: message
    };
  }

  /**
   * Clean up expired conversations
   */
  cleanupExpiredConversations() {
    const now = new Date();
    const expiredSessions = [];
    
    for (const [studentId, state] of this.conversationStates.entries()) {
      const lastActivity = new Date(state.lastActivity);
      if (now - lastActivity > this.sessionTimeout) {
        expiredSessions.push(studentId);
      }
    }
    
    expiredSessions.forEach(studentId => {
      this.conversationStates.delete(studentId);
      this.assessmentResults.delete(studentId);
    });
    
    if (expiredSessions.length > 0) {
      console.log(`🧹 Cleaned up ${expiredSessions.length} expired conversations`);
    }
  }

  /**
   * Create fallback topic selection when Claude API fails
   * @param {Object} syllabusAnalysis - Syllabus analysis
   * @param {Object} studyCapacity - Study capacity
   * @param {Object} academicContext - Academic context
   * @returns {Object} Fallback topic selection
   */
  createFallbackTopicSelection(syllabusAnalysis, studyCapacity, academicContext) {
    console.log('🔄 Using fallback topic selection due to Claude API failure');
    
    try {
      // Get high-weightage topics as baseline
      const highWeightageTopics = this.knowledgeBase.getHighWeightageTopics('all').slice(0, 15);
      
      // Calculate realistic topic count based on study capacity
      const topicsToSelect = Math.min(
        studyCapacity.syllabusCompletionEstimate?.maxTopicsCanCover || 20,
        25 // Maximum fallback topics
      );
      
      // Simple strategy based on study capacity
      let strategy = 'Balanced Foundation Building';
      let reasoning = 'Fallback selection focusing on high-weightage NEET topics with balanced difficulty progression.';
      
      if (studyCapacity.dailyHours <= 4) {
        strategy = 'High-Yield Priority Focus';
        reasoning = 'Limited time available - focusing only on most important high-weightage topics.';
      } else if (studyCapacity.dailyHours >= 8) {
        strategy = 'Comprehensive Coverage';
        reasoning = 'Excellent time availability - comprehensive topic coverage with strong foundation building.';
      }
      
      // Create selected topics with basic prioritization
      const selectedTopics = highWeightageTopics.slice(0, topicsToSelect).map((topicName, index) => {
        const priority = index < 5 ? 'Critical' : index < 12 ? 'High' : 'Medium';
        const daysRequired = priority === 'Critical' ? 3 : priority === 'High' ? 2 : 1;
        
        return {
          topicName: topicName,
          subject: this.inferSubjectFromTopic(topicName),
          classLevel: '11', // Default to class 11
          priority: priority,
          daysRequired: daysRequired,
          startDate: this.calculateStartDate(index * daysRequired),
          endDate: this.calculateEndDate(index * daysRequired + daysRequired),
          reason: `High-weightage NEET topic (${priority} priority)`,
          complementaryTopics: [],
          studentRelevance: 'Important for NEET score improvement',
          id: `fallback_${index + 1}`,
          weightage: 5, // Default weightage
          difficulty: 'Medium',
          topics: [topicName],
          selectionRank: index + 1
        };
      });
      
      return {
        strategy: strategy,
        reasoning: reasoning,
        totalAvailableTopics: 100, // Approximate total
        selectedTopics: selectedTopics,
        priorityBreakdown: {
          critical: selectedTopics.filter(t => t.priority === 'Critical').length,
          high: selectedTopics.filter(t => t.priority === 'High').length,
          medium: selectedTopics.filter(t => t.priority === 'Medium').length
        },
        studentDataIntegration: {
          weakTopicsAddressed: Math.floor(selectedTopics.length * 0.4),
          strongTopicsReinforced: Math.floor(selectedTopics.length * 0.2),
          balancingStrategy: 'Balanced approach focusing on high-weightage topics with fallback prioritization'
        },
        claudeRecommendations: [
          'Focus on understanding concepts rather than memorization',
          'Practice previous year questions for selected topics',
          'Maintain consistent daily study schedule',
          'Regular revision of completed topics'
        ]
      };
    } catch (error) {
      console.error('❌ Fallback topic selection also failed:', error.message);
      
      // Ultimate fallback with minimal topics
      return {
        strategy: 'Basic NEET Preparation',
        reasoning: 'Basic topic selection due to system limitations',
        totalAvailableTopics: 50,
        selectedTopics: [
          {
            topicName: 'Mechanics',
            subject: 'physics',
            classLevel: '11',
            priority: 'Critical',
            daysRequired: 7,
            startDate: this.calculateStartDate(0),
            endDate: this.calculateEndDate(7),
            reason: 'Fundamental physics topic',
            complementaryTopics: [],
            studentRelevance: 'Core NEET topic',
            id: 'basic_1',
            weightage: 8,
            difficulty: 'Medium',
            topics: ['Mechanics'],
            selectionRank: 1
          }
        ],
        priorityBreakdown: { critical: 1, high: 0, medium: 0 },
        studentDataIntegration: {
          weakTopicsAddressed: 1,
          strongTopicsReinforced: 0,
          balancingStrategy: 'Basic approach due to system limitations'
        },
        claudeRecommendations: [
          'Start with fundamental concepts',
          'Seek additional guidance from teachers'
        ]
      };
    }
  }

  /**
   * Infer subject from topic name
   * @param {string} topicName - Topic name
   * @returns {string} Subject (physics/chemistry/biology)
   */
  inferSubjectFromTopic(topicName) {
    const physicsKeywords = ['mechanics', 'kinematics', 'dynamics', 'waves', 'optics', 'electricity', 'magnetism'];
    const chemistryKeywords = ['organic', 'inorganic', 'physical', 'reaction', 'bonding', 'structure', 'equilibrium'];
    const biologyKeywords = ['cell', 'genetics', 'evolution', 'ecology', 'plant', 'animal', 'human', 'reproduction'];
    
    const topicLower = topicName.toLowerCase();
    
    if (physicsKeywords.some(keyword => topicLower.includes(keyword))) {
      return 'physics';
    } else if (chemistryKeywords.some(keyword => topicLower.includes(keyword))) {
      return 'chemistry';
    } else if (biologyKeywords.some(keyword => topicLower.includes(keyword))) {
      return 'biology';
    }
    
    return 'physics'; // Default fallback
  }

  /**
   * Calculate start date for topic
   * @param {number} dayOffset - Day offset from today
   * @returns {string} Start date in MM/DD format
   */
  calculateStartDate(dayOffset) {
    const date = new Date();
    date.setDate(date.getDate() + dayOffset);
    return `${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')}`;
  }

  /**
   * Calculate end date for topic
   * @param {number} dayOffset - Day offset from today
   * @returns {string} End date in MM/DD format
   */
  calculateEndDate(dayOffset) {
    const date = new Date();
    date.setDate(date.getDate() + dayOffset);
    return `${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')}`;
  }

  /**
   * Get conversation statistics
   * @returns {Object} Statistics
   */
  getStatistics() {
    return {
      activeConversations: this.conversationStates.size,
      completedAssessments: this.assessmentResults.size,
      averageQuestionsPerSession: this.getAverageQuestionsPerSession(),
      phaseDistribution: this.getPhaseDistribution()
    };
  }

  /**
   * Get average questions per session
   * @returns {number} Average questions
   */
  getAverageQuestionsPerSession() {
    const sessions = Array.from(this.conversationStates.values());
    const totalQuestions = sessions.reduce((sum, session) => sum + session.questionsAsked, 0);
    return sessions.length > 0 ? totalQuestions / sessions.length : 0;
  }

  /**
   * Get phase distribution
   * @returns {Object} Phase distribution
   */
  getPhaseDistribution() {
    const phases = {};
    
    for (const state of this.conversationStates.values()) {
      phases[state.currentPhase] = (phases[state.currentPhase] || 0) + 1;
    }
    
    return phases;
  }

  /**
   * Build foundation recovery section for Claude prompt
   * @param {Object} foundationRecoveryPlan - Foundation recovery plan
   * @returns {string} Foundation recovery prompt section
   */
  buildFoundationRecoverySection(foundationRecoveryPlan) {
    if (!foundationRecoveryPlan || !foundationRecoveryPlan.foundationRequired) {
      return '';
    }

    const criticalChapters = foundationRecoveryPlan.criticalClass11Chapters
      .slice(0, 10) // Show top 10 critical chapters
      .map(chapter => `- **${chapter.name}** (${chapter.subject}, Priority: ${chapter.priority}) - Required for: ${chapter.forClass12Topic}`)
      .join('\n');

    const parallelPairs = foundationRecoveryPlan.parallelStudyPairs
      .slice(0, 5) // Show top 5 parallel study pairs
      .map(pair => `- Study "${pair.class11.name}" (Class 11) BEFORE "${pair.class12.name}" (Class 12)`)
      .join('\n');

    return `
## 🚨 CRITICAL: CLASS 11 FOUNDATION RECOVERY REQUIRED
This Class 12 student has weak areas in topics that require strong Class 11 foundations. **YOU MUST prioritize these Class 11 chapters FIRST**.

### Critical Class 11 Chapters to Cover First (${foundationRecoveryPlan.criticalClass11Chapters.length} total):
${criticalChapters}

### Recommended Parallel Study Pairs:
${parallelPairs}

### Foundation Recovery Strategy:
- **Total Recovery Time:** ~${foundationRecoveryPlan.totalRecoveryTime} days
- **Priority Order:** ${foundationRecoveryPlan.priorityOrder.slice(0, 3).join(' → ')}
- **Approach:** Study critical Class 11 foundations BEFORE attempting related Class 12 topics

**IMPORTANT:** Without these Class 11 foundations, the student will struggle with related Class 12 topics. Prioritize foundation recovery for maximum learning efficiency.
`;
  }

  /**
   * Generate comprehensive study techniques for student topics
   * @param {Object} syllabusAnalysis - Student's syllabus analysis
   * @param {Array} selectedTopics - Selected topics for study plan
   * @param {Object} motivationalContext - Student's motivational context
   * @returns {Promise<Object>} Study techniques including mind maps, mnemonics, visual aids
   */
  async generateStudyTechniques(syllabusAnalysis, selectedTopics, motivationalContext) {
    console.log('🧠 Generating study techniques for selected topics');
    
    try {
      const weakTopics = syllabusAnalysis.weakTopics || [];
      const learningStyle = this.determineLearningStyle(motivationalContext);
      
      // Group topics by subject
      const topicsBySubject = this.groupTopicsBySubject(selectedTopics);
      
      // Generate techniques for each subject
      const studyTechniques = {};
      
      for (const [subject, chapters] of Object.entries(topicsBySubject)) {
        studyTechniques[subject] = {};
        
        // Process up to 3 most important chapters per subject to avoid overwhelming
        const priorityChapters = chapters.slice(0, 3);
        
        for (const chapter of priorityChapters) {
          const chapterWeakTopics = weakTopics.filter(topic => 
            topic.toLowerCase().includes(chapter.toLowerCase()) ||
            chapter.toLowerCase().includes(topic.toLowerCase())
          );
          
          studyTechniques[subject][chapter] = await this.studyTechniqueService.generateStudyTechniques(
            subject,
            chapter,
            chapterWeakTopics,
            learningStyle
          );
        }
      }
      
      // Generate overall study methodology
      const overallMethodology = await this.generateOverallStudyMethodology(
        weakTopics,
        learningStyle,
        selectedTopics.length
      );
      
      return {
        bySubject: studyTechniques,
        overallMethodology: overallMethodology,
        learningStyle: learningStyle,
        totalTechniques: Object.keys(studyTechniques).reduce((total, subject) => 
          total + Object.keys(studyTechniques[subject]).length, 0
        ),
        focusAreas: weakTopics.slice(0, 5), // Top 5 focus areas
        practiceRecommendations: this.generatePracticeRecommendations(weakTopics, selectedTopics)
      };
      
    } catch (error) {
      console.error('❌ Error generating study techniques:', error.message);
      return this.getDefaultStudyTechniques(syllabusAnalysis, selectedTopics);
    }
  }

  /**
   * Generate sample questions with detailed solutions for weak topics
   * @param {Array} weakTopics - Student's weak topics
   * @param {string} subject - Subject name
   * @param {string} chapter - Chapter name
   * @returns {Promise<Object>} Sample questions with comprehensive solutions
   */
  async generateSampleQuestionsWithSolutions(weakTopics, subject, chapter) {
    console.log(`📝 Generating sample questions with solutions for ${subject} - ${chapter}`);
    
    try {
      // Generate a practice question for the weak topic
      const questionPrompt = `Generate a NEET-style practice question for ${subject} chapter: "${chapter}".

      Focus on these weak areas: ${weakTopics.join(', ')}

      Create:
      1. A clear, NEET-standard question
      2. Four multiple choice options (A, B, C, D)
      3. Specify the correct answer
      4. Include the difficulty level (Easy/Medium/Hard)

      Make the question focused on commonly tested concepts from this chapter.`;

      const questionResponse = await this.llmService.callClaudeAPI(questionPrompt);
      const question = this.parseQuestionResponse(questionResponse, subject, chapter);

      // Generate comprehensive solution using SolutionGeneratorService
      const solution = await this.solutionGeneratorService.generateComprehensiveSolution(
        question,
        question.options,
        question.correctAnswer,
        weakTopics
      );

      return {
        question: question,
        solution: solution,
        studyRecommendations: this.generateQuestionBasedStudyRecommendations(question, weakTopics)
      };

    } catch (error) {
      console.error('❌ Error generating sample questions:', error.message);
      return this.getDefaultQuestionSolution(subject, chapter);
    }
  }

  // Helper methods for study techniques
  determineLearningStyle(motivationalContext) {
    // Simple heuristic - can be enhanced with actual assessment
    const responses = motivationalContext.responses || [];
    const responseText = responses.join(' ').toLowerCase();
    
    if (responseText.includes('visual') || responseText.includes('diagram') || responseText.includes('chart')) {
      return 'visual';
    } else if (responseText.includes('listen') || responseText.includes('discuss') || responseText.includes('audio')) {
      return 'auditory';
    } else if (responseText.includes('practice') || responseText.includes('hands-on') || responseText.includes('activity')) {
      return 'kinesthetic';
    }
    
    return 'visual'; // Default to visual for NEET preparation
  }

  groupTopicsBySubject(selectedTopics) {
    const grouped = {
      'Biology': [],
      'Chemistry': [],
      'Physics': []
    };
    
    selectedTopics.forEach(topic => {
      if (typeof topic === 'object' && topic.name) {
        // Determine subject based on topic content or use existing subject field
        const subject = topic.subject || this.determineSubjectFromTopic(topic.name);
        if (grouped[subject]) {
          grouped[subject].push(topic.name);
        }
      } else if (typeof topic === 'string') {
        const subject = this.determineSubjectFromTopic(topic);
        if (grouped[subject]) {
          grouped[subject].push(topic);
        }
      }
    });
    
    return grouped;
  }

  determineSubjectFromTopic(topicName) {
    const topicLower = topicName.toLowerCase();
    
    // Biology keywords
    if (topicLower.includes('cell') || topicLower.includes('genetics') || topicLower.includes('evolution') ||
        topicLower.includes('plant') || topicLower.includes('animal') || topicLower.includes('human') ||
        topicLower.includes('ecology') || topicLower.includes('reproduction') || topicLower.includes('respiration')) {
      return 'Biology';
    }
    
    // Chemistry keywords
    if (topicLower.includes('organic') || topicLower.includes('inorganic') || topicLower.includes('chemical') ||
        topicLower.includes('reaction') || topicLower.includes('acid') || topicLower.includes('base') ||
        topicLower.includes('carbon') || topicLower.includes('periodic') || topicLower.includes('bond')) {
      return 'Chemistry';
    }
    
    // Physics keywords
    if (topicLower.includes('motion') || topicLower.includes('force') || topicLower.includes('energy') ||
        topicLower.includes('wave') || topicLower.includes('electric') || topicLower.includes('magnetic') ||
        topicLower.includes('optics') || topicLower.includes('mechanics') || topicLower.includes('thermodynamics')) {
      return 'Physics';
    }
    
    return 'Biology'; // Default fallback
  }

  async generateOverallStudyMethodology(weakTopics, learningStyle, totalTopics) {
    const methodologyPrompt = `Create an overall study methodology for a NEET student with these characteristics:

    Learning Style: ${learningStyle}
    Total Topics to Cover: ${totalTopics}
    Main Weak Areas: ${weakTopics.slice(0, 5).join(', ')}

    Provide:
    1. Daily Study Routine Template
    2. Weekly Review Strategy
    3. Monthly Assessment Plan
    4. Technique Integration Guide (how to use mind maps, mnemonics together)
    5. Time Management for Different Learning Techniques
    6. Progress Tracking Methods

    Make it practical and NEET-specific with actionable steps.`;

    try {
      const response = await this.llmService.callClaudeAPI(methodologyPrompt);
      return this.parseMethodologyResponse(response);
    } catch (error) {
      return {
        dailyRoutine: 'Follow structured study routine with technique variety',
        weeklyReview: 'Use spaced repetition and technique reinforcement',
        monthlyAssessment: 'Evaluate progress and adjust techniques',
        integrationGuide: 'Combine visual, auditory, and practical techniques',
        timeManagement: 'Allocate time based on learning style preferences',
        progressTracking: 'Monitor effectiveness of different techniques'
      };
    }
  }

  generatePracticeRecommendations(weakTopics, selectedTopics) {
    return {
      dailyQuestions: Math.min(10, selectedTopics.length * 2),
      weeklyTopicFocus: weakTopics.slice(0, 3),
      practiceSequence: ['Easy questions for confidence', 'Medium questions for understanding', 'Hard questions for mastery'],
      reviewCycle: 'Practice → Review → Reinforce → Test',
      difficultyProgression: '30% Easy, 50% Medium, 20% Hard'
    };
  }

  parseQuestionResponse(response, subject, chapter) {
    try {
      // Extract question, options, and answer from response
      const questionMatch = response.match(/(?:question|problem)[:\-\s]*([^]*?)(?=options|choices|\n\s*(?:a\)|A\)|\(a\)|\(A\)))/i);
      const question = questionMatch ? questionMatch[1].trim() : 'Practice question for understanding concepts';

      const optionsPattern = /(?:\(?[A-Da-d]\)?\.?\s*)([^]*?)(?=\(?[A-Da-d]\)?\.?|correct|answer|$)/gi;
      const options = [];
      let match;
      while ((match = optionsPattern.exec(response)) !== null && options.length < 4) {
        if (match[1].trim()) {
          options.push(match[1].trim());
        }
      }

      if (options.length < 4) {
        options.push('Option A', 'Option B', 'Option C', 'Option D');
      }

      const answerMatch = response.match(/(?:correct answer|answer)[:\-\s]*([A-Da-d])/i);
      const correctAnswer = answerMatch ? answerMatch[1].toUpperCase() : 'A';

      return {
        text: question,
        subject: subject,
        chapter: chapter,
        options: options.slice(0, 4),
        correctAnswer: correctAnswer,
        difficulty: this.extractDifficulty(response)
      };
    } catch (error) {
      return {
        text: `Practice question for ${chapter}`,
        subject: subject,
        chapter: chapter,
        options: ['Option A', 'Option B', 'Option C', 'Option D'],
        correctAnswer: 'A',
        difficulty: 'Medium'
      };
    }
  }

  extractDifficulty(text) {
    if (text.toLowerCase().includes('easy')) return 'Easy';
    if (text.toLowerCase().includes('hard') || text.toLowerCase().includes('difficult')) return 'Hard';
    return 'Medium';
  }

  parseMethodologyResponse(response) {
    return {
      dailyRoutine: this.extractSection(response, 'daily|routine'),
      weeklyReview: this.extractSection(response, 'weekly|review'),
      monthlyAssessment: this.extractSection(response, 'monthly|assessment'),
      integrationGuide: this.extractSection(response, 'integration|technique'),
      timeManagement: this.extractSection(response, 'time|management'),
      progressTracking: this.extractSection(response, 'progress|tracking'),
      fullMethodology: response
    };
  }

  extractSection(text, pattern) {
    const regex = new RegExp(`(?:${pattern})[:\-\s]*([^]*?)(?=\\n\\s*(?:\\d+\\.|[A-Z][a-z]+:)|$)`, 'i');
    const match = text.match(regex);
    return match ? match[1].trim() : `Follow structured approach for ${pattern.replace('|', '/')}`;
  }

  generateQuestionBasedStudyRecommendations(question, weakTopics) {
    return {
      conceptReview: `Review ${question.chapter} concepts, especially ${weakTopics.slice(0, 2).join(' and ')}`,
      practiceMore: `Practice similar ${question.difficulty} level questions on this topic`,
      timeAllocation: question.difficulty === 'Hard' ? '3-4 minutes per question' : '1-2 minutes per question',
      studyTips: `Focus on understanding the underlying principles in ${question.subject}`
    };
  }

  // Fallback methods
  getDefaultStudyTechniques(syllabusAnalysis, selectedTopics) {
    return {
      bySubject: {
        Biology: { 'General': { mindMap: 'Create concept maps for biological processes', mnemonics: 'Use acronyms for classifications' } },
        Chemistry: { 'General': { mindMap: 'Visualize reaction mechanisms', mnemonics: 'Create memory aids for periodic properties' } },
        Physics: { 'General': { mindMap: 'Map formula relationships', mnemonics: 'Remember constants with stories' } }
      },
      overallMethodology: { dailyRoutine: 'Study with variety of techniques', integrationGuide: 'Combine visual and verbal methods' },
      learningStyle: 'visual',
      totalTechniques: 3,
      focusAreas: syllabusAnalysis.weakTopics?.slice(0, 5) || [],
      practiceRecommendations: { dailyQuestions: 10, practiceSequence: ['Easy', 'Medium', 'Hard'] }
    };
  }

  getDefaultQuestionSolution(subject, chapter) {
    return {
      question: {
        text: `Practice question for ${chapter}`,
        subject: subject,
        chapter: chapter,
        options: ['Option A', 'Option B', 'Option C', 'Option D'],
        correctAnswer: 'A',
        difficulty: 'Medium'
      },
      solution: {
        stepByStepSolution: { steps: ['Understand the question', 'Apply relevant concepts', 'Calculate or reason', 'Select answer'] },
        quickTricks: { tricks: 'Use elimination and logical reasoning' }
      },
      studyRecommendations: { conceptReview: 'Focus on chapter fundamentals' }
    };
  }

  // ===== NEW ADAPTIVE QUIZ INTEGRATION METHODS =====

  /**
   * Check if adaptive quiz should be recommended for the student
   * @param {string} studentId - Student ID
   * @param {Object} syllabusAnalysis - Student's syllabus analysis
   * @returns {Promise<Object>} Adaptive quiz recommendation
   */
  async checkAdaptiveQuizRecommendation(studentId, syllabusAnalysis) {
    try {
      console.log(`🎯 Checking adaptive quiz recommendation for student: ${studentId}`);
      
      // Get student performance data from Lambda
      const studentData = await this.lambdaConnector.formatStudentDataForAI(
        await this.lambdaConnector.getStudentData(parseInt(studentId))
      );

      if (!studentData) {
        console.log(`ℹ️ No student data found for adaptive quiz analysis`);
        return {
          shouldRecommend: false,
          reasoning: 'No performance data available for analysis',
          triggers: [],
          adaptiveQuizUrl: null,
          currentOptimalLevels: []
        };
      }

      // Use AdaptiveDPPService to analyze and recommend
      const recommendation = await this.adaptiveDPPService.shouldRecommendAdaptiveQuiz(
        parseInt(studentId), 
        studentData
      );

      console.log(`✅ Adaptive quiz recommendation analysis complete:`, {
        shouldRecommend: recommendation.shouldRecommend,
        triggers: recommendation.triggers.length,
        reasoning: recommendation.reasoning
      });

      return recommendation;
    } catch (error) {
      console.error(`❌ Failed to check adaptive quiz recommendation:`, error.message);
      return {
        shouldRecommend: false,
        reasoning: `Error during analysis: ${error.message}`,
        triggers: [],
        adaptiveQuizUrl: null,
        currentOptimalLevels: []
      };
    }
  }

  /**
   * Save adaptive quiz state for future comparison
   * @param {string} studentId - Student ID
   * @param {Object} syllabusAnalysis - Student's current analysis
   * @param {Object} adaptiveQuizRecommendation - Quiz recommendation
   */
  async saveAdaptiveQuizState(studentId, syllabusAnalysis, adaptiveQuizRecommendation) {
    try {
      console.log(`💾 Saving adaptive quiz state for student: ${studentId}`);
      
      // Fetch detailed adaptive DPP performance for state saving
      const adaptivePerformance = await this.adaptiveDPPService.getAdaptiveDPPPerformance(parseInt(studentId));
      
      // Save state with trigger information
      const triggerReason = adaptiveQuizRecommendation.triggers.map(t => t.type).join(', ') || 'performance_analysis';
      await this.adaptiveDPPService.savePerformanceState(
        parseInt(studentId), 
        adaptivePerformance, 
        triggerReason
      );

      console.log(`✅ Adaptive quiz state saved for future optimal level comparison`);
    } catch (error) {
      console.error(`❌ Failed to save adaptive quiz state:`, error.message);
      // Don't throw - this is not critical for study plan generation
    }
  }

  /**
   * Enhanced buildStudyPlanResponse to include adaptive quiz recommendation
   * @param {Object} studyPlan - Generated study plan
   * @param {Object} academicContext - Academic context
   * @param {Object} adaptiveQuizRecommendation - Adaptive quiz recommendation
   * @returns {string} Enhanced study plan response
   */
  buildStudyPlanResponse(studyPlan, academicContext, adaptiveQuizRecommendation = null) {
    let response = '';
    
    // Build standard study plan response
    response += `🎯 **Your Personalized NEET Study Plan**\n\n`;
    
    if (studyPlan.motivationalMessage) {
      response += `${studyPlan.motivationalMessage}\n\n`;
    }

    // Add study strategy
    if (studyPlan.studyStrategy) {
      response += `📋 **Study Strategy:**\n`;
      response += `${studyPlan.studyStrategy}\n\n`;
    }

    // Add timeline if available
    if (studyPlan.timeline && studyPlan.timeline.detailedSchedule) {
      response += `📅 **Your Study Schedule:**\n`;
      const schedule = studyPlan.timeline.detailedSchedule;
      Object.entries(schedule).slice(0, 7).forEach(([date, topics]) => {
        response += `**${date}:** ${topics.join(', ')}\n`;
      });
      response += `\n`;
    }

    // Add prioritized topics
    if (studyPlan.prioritizedTopics && studyPlan.prioritizedTopics.length > 0) {
      response += `🎯 **Priority Topics to Focus On:**\n`;
      studyPlan.prioritizedTopics.slice(0, 5).forEach((topic, index) => {
        response += `${index + 1}. ${topic.chapter} (${topic.subject}) - ${topic.reason}\n`;
      });
      response += `\n`;
    }

    // 🎯 NEW: Add adaptive quiz recommendation if available
    if (adaptiveQuizRecommendation && adaptiveQuizRecommendation.shouldRecommend) {
      response += `🎮 **Adaptive Quiz Recommendation:**\n\n`;
      response += `Based on your performance analysis, I recommend taking an **Adaptive DPP Quiz** to optimize your learning:\n\n`;
      
      // Explain the triggers
      if (adaptiveQuizRecommendation.triggers && adaptiveQuizRecommendation.triggers.length > 0) {
        response += `**Why this recommendation?**\n`;
        adaptiveQuizRecommendation.triggers.forEach(trigger => {
          const emoji = trigger.severity === 'high' ? '🔴' : '🟡';
          response += `${emoji} ${trigger.condition}\n`;
        });
        response += `\n`;
      }

      // Show current optimal levels if available
      if (adaptiveQuizRecommendation.currentOptimalLevels && adaptiveQuizRecommendation.currentOptimalLevels.length > 0) {
        response += `**Your Current Optimal Difficulty Levels:**\n`;
        adaptiveQuizRecommendation.currentOptimalLevels.slice(0, 3).forEach(level => {
          const bandLabel = this.getDifficultyBandLabel(level.optimalBand);
          response += `• ${level.chapter}: ${bandLabel} (${level.accuracy}% accuracy)\n`;
        });
        response += `\n`;
      }

      // Provide the adaptive quiz link
      if (adaptiveQuizRecommendation.adaptiveQuizUrl) {
        response += `**🔗 Start Your Adaptive Quiz:**\n`;
        response += `${adaptiveQuizRecommendation.adaptiveQuizUrl}\n\n`;
        response += `This adaptive quiz will:\n`;
        response += `• Identify your current optimal difficulty level\n`;
        response += `• Serve questions in your "sweet spot" for maximum learning\n`;
        response += `• Track your progress and adjust difficulty automatically\n`;
        response += `• Compare your performance with previous attempts\n\n`;
      }
    }

    // Add study techniques if available
    if (studyPlan.studyTechniques) {
      response += `🧠 **Study Techniques:**\n`;
      if (studyPlan.studyTechniques.mindMaps) {
        response += `• Mind maps and visual learning aids included\n`;
      }
      if (studyPlan.studyTechniques.mnemonics) {
        response += `• Memory techniques and mnemonics provided\n`;
      }
      response += `\n`;
    }

    // Add motivational closing
    response += `💪 **Remember:** Consistency is key! Follow this plan daily and track your progress. `;
    
    if (adaptiveQuizRecommendation && adaptiveQuizRecommendation.shouldRecommend) {
      response += `Take the adaptive quiz when you feel ready to challenge yourself and see how your optimal difficulty level improves over time!`;
    } else {
      response += `Your performance looks stable - keep up the great work!`;
    }

    return response;
  }

  /**
   * Get difficulty band label for display
   * @param {number} bandIndex - Difficulty band index (0-9)
   * @returns {string} Human-readable difficulty label
   */
  getDifficultyBandLabel(bandIndex) {
    const bands = [
      'Very Easy (0-10%)', 'Easy (10-20%)', 'Easy-Medium (20-30%)', 
      'Medium-Easy (30-40%)', 'Medium (40-50%)', 'Medium-Hard (50-60%)',
      'Hard-Medium (60-70%)', 'Hard (70-80%)', 'Very Hard (80-90%)', 'Expert (90-100%)'
    ];
    return bands[bandIndex] || 'Unknown';
  }

  /**
   * Check user's adaptive quiz progression after quiz completion
   * @param {string} studentId - Student ID
   * @returns {Promise<Object>} Progression analysis
   */
  async checkAdaptiveQuizProgression(studentId) {
    try {
      console.log(`📊 Checking adaptive quiz progression for student: ${studentId}`);
      
      const progression = await this.adaptiveDPPService.getAdaptiveQuizProgression(parseInt(studentId));
      
      return {
        success: true,
        progression,
        message: this.buildProgressionMessage(progression),
        recommendations: this.generateProgressionRecommendations(progression)
      };
    } catch (error) {
      console.error(`❌ Failed to check adaptive quiz progression:`, error.message);
      return {
        success: false,
        error: error.message,
        progression: null,
        message: 'Unable to analyze your progression at this time.',
        recommendations: []
      };
    }
  }

  /**
   * Build progression message for user
   * @param {Object} progression - Progression data
   * @returns {string} User-friendly progression message
   */
  buildProgressionMessage(progression) {
    if (!progression || progression.totalChaptersTracked === 0) {
      return 'No adaptive quiz progression data available yet. Take your first adaptive quiz to start tracking!';
    }

    let message = `📈 **Your Adaptive Quiz Progression:**\n\n`;
    message += `**Chapters Tracked:** ${progression.totalChaptersTracked}\n`;
    message += `**Overall Trend:** ${progression.overallTrend.toUpperCase()}\n`;
    
    if (progression.lastActivity) {
      const lastDate = new Date(progression.lastActivity).toLocaleDateString();
      message += `**Last Activity:** ${lastDate}\n\n`;
    }

    if (progression.chapterProgressions && progression.chapterProgressions.length > 0) {
      message += `**Top Performing Chapters:**\n`;
      progression.chapterProgressions.slice(0, 3).forEach((chapter, index) => {
        const trend = chapter.masteryImprovements > chapter.masteryDeclines ? '📈' : 
                     chapter.masteryDeclines > chapter.masteryImprovements ? '📉' : '➡️';
        message += `${index + 1}. ${chapter.chapterName} ${trend} (${chapter.masteryImprovements} improvements)\n`;
      });
    }

    return message;
  }

  /**
   * Generate recommendations based on progression
   * @param {Object} progression - Progression data
   * @returns {Array} Array of recommendation objects
   */
  generateProgressionRecommendations(progression) {
    const recommendations = [];

    if (progression.overallTrend === 'improving') {
      recommendations.push({
        type: 'positive_reinforcement',
        message: 'Excellent progress! Continue with your current study strategy.',
        action: 'maintain_current_approach'
      });
    } else if (progression.overallTrend === 'declining') {
      recommendations.push({
        type: 'course_correction',
        message: 'Consider reviewing fundamental concepts and taking more practice quizzes.',
        action: 'focus_on_fundamentals'
      });
    } else {
      recommendations.push({
        type: 'challenge_increase',
        message: 'Your performance is stable. Try challenging yourself with harder topics.',
        action: 'increase_difficulty'
      });
    }

    if (progression.totalChaptersTracked < 5) {
      recommendations.push({
        type: 'expand_practice',
        message: 'Take adaptive quizzes in more subjects to get a comprehensive analysis.',
        action: 'diversify_practice'
      });
    }

    return recommendations;
  }
}

module.exports = ConversationalAssessmentManager;